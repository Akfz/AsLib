package v.akfz.aslib.util;

import net.minecraft.class_2561;
import net.minecraft.class_5250;

public final class TranslateUtils {
	private TranslateUtils() {}

	public static String getString(String key, Object... args) {
		return class_2561.method_43469(key, args).getString();
	}

	public static class_5250 getComponent(String key, Object... args) {
		return class_2561.method_43469(key, args);
	}

	public static String buildKey(String modId, String category, String name) {
		return modId + "." + category + "." + name;
	}

	public static boolean hasTranslation(String key) {
		String translated = class_2561.method_43471(key).getString();
		return !translated.equals(key);
	}
}