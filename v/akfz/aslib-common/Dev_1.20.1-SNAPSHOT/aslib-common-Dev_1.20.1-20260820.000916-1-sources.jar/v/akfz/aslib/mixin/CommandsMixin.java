package v.akfz.aslib.mixin;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import v.akfz.aslib.command.CommandHandler;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2170.class)
public class CommandsMixin {

    @Shadow @Final private CommandDispatcher<class_2168> dispatcher;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void onInitCommands(class_2170.class_5364 selection, net.minecraft.class_7157 context, CallbackInfo ci) {
        CommandHandler.setDispatcher(this.dispatcher);
    }
}