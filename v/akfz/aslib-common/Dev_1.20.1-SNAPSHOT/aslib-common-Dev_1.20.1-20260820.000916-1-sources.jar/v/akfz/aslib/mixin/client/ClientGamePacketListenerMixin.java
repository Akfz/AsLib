package v.akfz.aslib.mixin.client;

import v.akfz.aslib.network.AsLibNetworking;
import v.akfz.aslib.network.api.Packet;
import net.minecraft.class_2540;
import net.minecraft.class_2658;
import net.minecraft.class_2960;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_634.class})
public class ClientGamePacketListenerMixin {
    @Inject(
            method = {"handleCustomPayload"},
            at = {@At("HEAD")},
            cancellable = true
    )
    public void aslib$onCustomPayload(class_2658 packet, CallbackInfo ci) {
        class_2960 id = packet.method_11456();
        if (AsLibNetworking.REGISTRY.isPresent(id)) {
            class_2540 buf = packet.method_11458();
            Packet decodedPacket = AsLibNetworking.REGISTRY.get(id).decoder().decode(buf);

            try {
                AsLibNetworking.HANDLER.handle(decodedPacket);
            } catch (Exception e) {
                e.printStackTrace();
            }

            ci.cancel();
        }
    }
}
