package v.akfz.aslib.mixin;

import v.akfz.aslib.network.AsLibNetworking;
import v.akfz.aslib.network.api.Packet;
import net.minecraft.class_2540;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_3244.class})
public class SrvGamePacketListenerImplMixin {
    @Shadow
    public class_3222 player;

    @Inject(method = "handleCustomPayload", at = @At("HEAD"), cancellable = true)
    private void aslib$onCustomPayload(class_2817 packet, CallbackInfo ci) {
        class_2960 id = packet.method_36169();
        if (AsLibNetworking.REGISTRY.isPresent(id)) {
            class_2540 buf = packet.method_36170();
            Packet decodedPacket = AsLibNetworking.REGISTRY.get(id).decoder().decode(buf);
            class_3222 sender = this.player;

            sender.method_5682().execute(() -> {
                try {
                    AsLibNetworking.HANDLER.handle(decodedPacket, sender);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            ci.cancel();
        }
    }
}
