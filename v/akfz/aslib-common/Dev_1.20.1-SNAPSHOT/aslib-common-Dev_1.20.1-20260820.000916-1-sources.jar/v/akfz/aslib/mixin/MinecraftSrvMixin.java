package v.akfz.aslib.mixin;

import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import v.akfz.aslib.AsLib;
import v.akfz.aslib.event.impl.FirstTickEvent;
import v.akfz.aslib.event.impl.TickUpdater;
import v.akfz.aslib.world.MinecraftServerExtension;

import java.util.Map;

@Mixin(MinecraftServer.class)
public abstract class MinecraftSrvMixin implements MinecraftServerExtension {

    @Unique
    private boolean started = false;

    @Inject(method = "tickChildren", at = @At("TAIL"))
    private void aslib$onTickEnd(CallbackInfo ci) {
        if (!started) {
            AsLib.EVENT_BUS.post(new FirstTickEvent());
            started = true;
        }
        AsLib.EVENT_BUS.post(new TickUpdater(false));
    }

    @Shadow @Final private Map<class_5321<class_1937>, class_3218> levels;
    @Shadow @Final protected class_32.class_5143 storageSource;

    @Override
    public Map<class_5321<class_1937>, class_3218> aslib$getLevels() {
        return this.levels;
    }

    @Override
    public class_32.class_5143 aslib$getStorageSource() {
        return this.storageSource;
    }
}