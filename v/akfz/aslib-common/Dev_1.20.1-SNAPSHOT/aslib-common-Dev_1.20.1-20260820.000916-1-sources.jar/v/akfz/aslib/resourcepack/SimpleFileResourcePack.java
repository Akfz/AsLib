package v.akfz.aslib.resourcepack;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3270;
import net.minecraft.class_7367;

/**
 * File-system backed implementation of {@link class_3262} that caches files from disk.
 */
public class SimpleFileResourcePack implements class_3262, FileResourcePack {
    private final String pack_name;
    private final String namespace;
    private final Set<String> known_namespaces;
    private final Path root;

    private final Map<String, Path> cacheFiles = new ConcurrentHashMap<>();

    public SimpleFileResourcePack(String packName, Path root, String namespace) {
        this.pack_name = packName;
        this.root = root;
        this.namespace = namespace;
        this.known_namespaces = Set.of(namespace);
        preloadCache();
    }

    @Override
    public String getSimpleNamespace() {
        return this.namespace;
    }

    public Map<String, Path> getCache() {
        return new HashMap<>(cacheFiles);
    }

    private void preloadCache() {
        try (Stream<Path> stream = Files.walk(root)) {
            stream.filter(Files::isRegularFile).forEach(path -> {
                String relativePath = root.relativize(path).toString().replace("\\", "/");
                cacheFiles.put(relativePath, path);
            });
        } catch (IOException e) {
            System.err.println("Error preloading cache for " + pack_name + ": " + e.getMessage());
        }
    }

    @Override
    public void refreshCache() {
        cacheFiles.clear();
        preloadCache();
    }

    @Override
    public class_3262 getPack() {
        return this;
    }

    @Override
    public @Nullable class_7367<InputStream> method_14410(String... strings) {
        String pathStr = String.join("/", strings);
        Path filePath = root.resolve(pathStr);
        if (Files.exists(filePath)) {
            return class_7367.create(filePath);
        }
        return null;
    }

    @Override
    public @Nullable class_7367<InputStream> method_14405(class_3264 packType, class_2960 resourceLocation) {
        if (!resourceLocation.method_12836().equals(namespace)) {
            return null;
        }

        String path = resourceLocation.method_12832();
        Path filePath = cacheFiles.get(path);

        if (filePath == null || !Files.exists(filePath)) {
            String folderPrefix = (packType == class_3264.field_14188 ? "assets/" : "data/") + namespace + "/";
            filePath = cacheFiles.get(folderPrefix + path);
        }

        if (filePath != null && Files.exists(filePath)) {
            return class_7367.create(filePath);
        }

        return null;
    }

    @Override
    public void method_14408(class_3264 packType, String namespace, String prefix, class_7664 resourceOutput) {
        if (!namespace.equals(this.namespace)) {
            return;
        }

        String folderPrefix = (packType == class_3264.field_14188 ? "assets/" : "data/") + namespace + "/";

        for (Map.Entry<String, Path> entry : cacheFiles.entrySet()) {
            String key = entry.getKey();
            Path filePath = entry.getValue();

            String relativePath = key;
            if (key.startsWith(folderPrefix)) {
                relativePath = key.substring(folderPrefix.length());
            }

            if (relativePath.startsWith(prefix)) {
                class_2960 id = new class_2960(namespace, relativePath);
                resourceOutput.accept(id, class_7367.create(filePath));
            }
        }
    }

    @Override
    public @NotNull Set<String> method_14406(class_3264 packType) {
        return known_namespaces;
    }

    @Override
    public @Nullable <T> T method_14407(class_3270<T> metadataSectionSerializer) throws IOException {
        return null;
    }

    @Override
    public String method_14409() {
        return pack_name;
    }

    @Override
    public void close() {
        cacheFiles.clear();
    }
}