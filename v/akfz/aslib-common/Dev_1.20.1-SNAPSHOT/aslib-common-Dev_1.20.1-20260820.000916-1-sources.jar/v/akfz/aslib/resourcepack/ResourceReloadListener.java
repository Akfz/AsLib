package v.akfz.aslib.resourcepack;

import net.minecraft.class_3300;

public interface ResourceReloadListener {
    void onReload(class_3300 manager);
}
