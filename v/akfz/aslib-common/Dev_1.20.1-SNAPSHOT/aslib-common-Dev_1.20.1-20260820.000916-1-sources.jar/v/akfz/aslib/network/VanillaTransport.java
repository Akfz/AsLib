package v.akfz.aslib.network;

import net.minecraft.class_2540;
import net.minecraft.class_3222;
import v.akfz.aslib.network.api.Packet;

public interface VanillaTransport {
    default void sendToServer(Packet packet) {
    }

    default void sendToServer(Packet packet, class_2540 buf) {
    }

    default void sendToPlayer(class_3222 player, Packet packet) {
    }

    default void sendToPlayer(class_3222 player, Packet packet, class_2540 buf) {
    }
}
