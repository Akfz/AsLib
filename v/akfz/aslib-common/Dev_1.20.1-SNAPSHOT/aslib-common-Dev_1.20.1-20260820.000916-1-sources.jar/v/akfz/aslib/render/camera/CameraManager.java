package v.akfz.aslib.render.camera;

import v.akfz.aslib.render.camera.event.CameraEvent;
import v.akfz.aslib.render.camera.event.InfiniteCameraEvent;
import v.akfz.aslib.util.math.CompositePair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_243;
import net.minecraft.class_310;

/**
 * Camera helper, idk why, but in my mod ts is needed
 * rotSpeed, posSpeed its interpolation speed
 */
public class CameraManager {
    public static CompositePair<Float> XRots = CompositePair.empty(Float.class);
    public static CompositePair<Float> YRots = CompositePair.empty(Float.class);
    public static CompositePair<Float> ZRots = CompositePair.empty(Float.class);

    public static CompositePair<Float> XPoses = CompositePair.empty(Float.class);
    public static CompositePair<Float> YPoses = CompositePair.empty(Float.class);
    public static CompositePair<Float> ZPoses = CompositePair.empty(Float.class);

    public static float rotSpeed = 15f;
    public static float posSpeed = 10f;

    private static final Map<String, CameraEvent> events = new HashMap<>();
    public static void addEvent(String id,CameraEvent event) {
        events.put(id,event);
    }
    public static void removeEvent(String id) {
        events.remove(id);
    }

    public static void update() {
        class_310 client = class_310.method_1551();
        if (client.field_1719 == null) {
            return;
        }

        events.values().forEach(CameraEvent::doPrevSet);
        ((CameraExtender) client.field_1773.method_19418()).addPos(new class_243(XPoses.get(), YPoses.get(), ZPoses.get()));
        ((CameraExtender) client.field_1773.method_19418()).clearRots();
        ((CameraExtender) client.field_1773.method_19418()).addRot(new class_243(XRots.get(), YRots.get(), ZRots.get()));
        List<String> toRemove = new ArrayList<>();
        events.forEach((id, camEvent) -> {
            camEvent.doAfterSet();

            if (!(camEvent instanceof InfiniteCameraEvent)) {
                toRemove.add(id);
            }
        });
        toRemove.forEach(events::remove);
    }
}
