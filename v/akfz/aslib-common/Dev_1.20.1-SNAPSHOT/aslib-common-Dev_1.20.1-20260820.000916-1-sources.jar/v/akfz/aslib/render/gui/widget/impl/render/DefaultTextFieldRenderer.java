package v.akfz.aslib.render.gui.widget.impl.render;

import v.akfz.aslib.render.color.ColorUtils;
import v.akfz.aslib.render.gui.widget.api.render.RenderExtras;
import v.akfz.aslib.render.gui.widget.api.render.RenderPart;
import v.akfz.aslib.render.gui.widget.impl.text.helper.LineRenderer;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import org.joml.Vector4f;

public class DefaultTextFieldRenderer implements RenderPart {

    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float delta, int x, int y, int width, int height, RenderExtras extras) {
        String text = extras.getOrDefault("text", String.class, "");
        String placeholder = extras.getOrDefault("placeholder", String.class, "");
        int cursorPos = extras.getOrDefault("cursorPos", Integer.class, 0);
        int selStart = extras.getOrDefault("selStart", Integer.class, -1);
        int selEnd = extras.getOrDefault("selEnd", Integer.class, -1);
        int scrollX = extras.getOrDefault("scrollX", Integer.class, 0);
        boolean editable = extras.getOrDefault("editable", Boolean.class, true);
        boolean focused = extras.getOrDefault("focused", Boolean.class, false);
        boolean cursorVisible = extras.getOrDefault("cursorVisible", Boolean.class, true);
        LineRenderer lineRenderer = extras.get("lineRenderer", LineRenderer.class);

        int bgColor = ColorUtils.rgbToArgb(255, 30, 30, 30);
        int borderColor = focused ? ColorUtils.rgbToArgb(255, 140, 140, 140) : ColorUtils.rgbToArgb(255, 70, 70, 70);
        int txtColor = editable ? 0xE0E0E0 : 0xA0A0A0;
        int placeholderColor = 0x808080;
        int selectionColor = ColorUtils.rgbToArgb(100, 0, 120, 215);
        int cursorColor = 0xFFFFFFFF;

        class_327 font = class_310.method_1551().field_1772;

        graphics.method_25294(x, y, x + width, y + height, bgColor);
        graphics.method_49601(x, y, width, height, borderColor);

        int textY = y + (height - font.field_2000) / 2;

        if (text.isEmpty() && !focused && !placeholder.isEmpty()) {
            graphics.method_51433(font, placeholder, x + 5, textY, placeholderColor, false);
            return;
        }

        Vector4f screenPos = new Vector4f((float) x, (float) y, 0.0F, 1.0F);
        screenPos.mul(graphics.method_51448().method_23760().method_23761());

        int actualX = Math.round(screenPos.x());
        int actualY = Math.round(screenPos.y());

        graphics.method_44379(actualX + 3, actualY + 2, actualX + width - 3, actualY + height - 2);

        class_4587 poseStack = graphics.method_51448();
        poseStack.method_22903();
        poseStack.method_46416(x + 4 - scrollX, textY, 0);

        int selMin = Math.min(selStart, selEnd);
        int selMax = Math.max(selStart, selEnd);
        if (selStart != -1 && selEnd != -1 && selStart != selEnd) {
            int startSelCol = Math.max(0, selMin);
            int endSelCol = Math.min(text.length(), selMax);

            int selX1 = font.method_1727(text.substring(0, startSelCol));
            int selX2 = font.method_1727(text.substring(0, endSelCol));

            graphics.method_25294(selX1, 0, selX2, font.field_2000, selectionColor);
        }

        if (lineRenderer != null) {
            lineRenderer.render(graphics, text, 0, 0, 0, 0, txtColor);
        } else {
            graphics.method_51433(font, text, 0, 0, txtColor, false);
        }

        if (focused && cursorVisible && editable && cursorPos >= 0 && cursorPos <= text.length()) {
            int cursorX = font.method_1727(text.substring(0, cursorPos));
            graphics.method_25294(cursorX, 0, cursorX + 1, font.field_2000, cursorColor);
        }

        poseStack.method_22909();
        graphics.method_44380();
    }
}