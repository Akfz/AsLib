package v.akfz.aslib.resourcepack.configpack;

import java.util.List;
import net.minecraft.class_3288;

/**
 * Data model for JSON-defined config pack properties.
 */
public class ConfigPackData implements ConfigData {
    public String name;
    public String id;
    public boolean alwaysEnabled;
    public List<String> description;
    public boolean pinned;
    public class_3288.class_3289 position;
    public String type = "default";

    /**
     * "client", "server" or "both" (default "both")
     */
    public String packTarget = "both";
}