package v.akfz.aslib.world;

import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_5321;

/**
 * Mixin.
 */
public interface MinecraftServerExtension {
    Map<class_5321<class_1937>, class_3218> aslib$getLevels();
    class_32.class_5143 aslib$getStorageSource();
}