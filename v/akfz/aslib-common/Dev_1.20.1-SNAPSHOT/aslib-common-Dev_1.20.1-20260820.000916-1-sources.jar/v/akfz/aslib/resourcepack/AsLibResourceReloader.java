package v.akfz.aslib.resourcepack;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;

/**
 * Custom reload listener that updates file caches and triggers registered callbacks when resources/data are reloaded.
 */
public final class AsLibResourceReloader implements class_3302 {
    @Override
    public CompletableFuture<Void> method_25931(class_4045 synchronizer, class_3300 manager, class_3695 prepareProfiler,
                                          class_3695 applyProfiler, Executor prepareExecutor, Executor applyExecutor) {
        return synchronizer.method_18352(null).thenRunAsync(() -> {
            applyProfiler.method_15396("aslib_cache_refresh");
            try {
                manager.method_29213().forEach(pack -> {
                    if (pack instanceof FileResourcePack frp) {
                        frp.refreshCache();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                applyProfiler.method_15407();
            }

            applyProfiler.method_15396("aslib_reload_callbacks");
            try {
                manager.method_29213().forEach(pack -> {
                    ResourceReloadListener listener = AsLibResourceReloaderHelper.getListener(pack);

                    if (listener != null) {
                        try {
                            listener.onReload(manager);
                        } catch (Exception e) {
                            System.err.println("[ASLib] Error inside listener for pack: " + pack.method_14409());
                            e.printStackTrace();
                        }
                    }
                });

                for (ResourceReloadListener globalListener : AsLibResourceReloaderHelper.getGlobalListeners()) {
                    try {
                        globalListener.onReload(manager);
                    } catch (Exception e) {
                        System.err.println("[ASLib] Error inside global resource reload listener");
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                applyProfiler.method_15407();
            }
        }, applyExecutor);
    }
}