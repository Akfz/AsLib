package v.akfz.aslib.datagen.block.blockstate;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import v.akfz.aslib.datagen.api.DataSerializable;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;

/**
 * Generates blockstates from BlockStateVariant 🐱
 */
public class BlockStateData extends DataSerializable {
    private final List<BlockStateVariant> variants = new ArrayList<>();

    public BlockStateData(class_2960 blockId) {
        super(new class_2960(blockId.method_12836(), "blockstates/" + blockId.method_12832()));
    }

    public BlockStateData addVariant(BlockStateVariant variant) {
        if (variant != null) {
            this.variants.add(variant);
        }
        return this;
    }

    @Override
    public Path getPath() {
        return null;
    }

    @Override
    public JsonElement serialize() {
        JsonObject rootJson = new JsonObject();
        JsonObject variantsJson = new JsonObject();

        for (BlockStateVariant variant : variants) {
            variantsJson.add(variant.getKey(), variant.serialize());
        }

        rootJson.add("variants", variantsJson);
        return rootJson;
    }
}
