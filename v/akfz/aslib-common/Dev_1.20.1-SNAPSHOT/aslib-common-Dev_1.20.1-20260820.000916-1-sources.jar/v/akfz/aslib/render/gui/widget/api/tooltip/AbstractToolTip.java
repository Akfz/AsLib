package v.akfz.aslib.render.gui.widget.api.tooltip;

import v.akfz.aslib.render.color.ColorUtils;
import v.akfz.aslib.render.gui.widget.api.render.RenderExtras;
import v.akfz.aslib.render.gui.widget.api.render.RenderPart;
import v.akfz.aslib.render.gui.widget.impl.render.DefaultToolTipRenderer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4068;

/**
 * Simple tooltip
 */
public abstract class AbstractToolTip implements class_4068 {
    protected int x, y, width, height;
    protected boolean visible = true;

    protected RenderPart Renderer;
    protected int backgroundColor = ColorUtils.rgbToArgb(80);
    protected List<String> text = new ArrayList<>();

    public AbstractToolTip(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (!visible || text == null || text.isEmpty())
            return;

        var tr = class_310.method_1551().field_1772;

        int maxTextWidth = 0;
        for (String line : text) {
            maxTextWidth = Math.max(maxTextWidth, tr.method_1727(line));
        }
        int totalWidth = maxTextWidth + 8;
        int totalHeight = text.size() * (tr.field_2000 + 2) + 6;

        int renderX = mouseX + 12;
        int renderY = mouseY - 12;

        int screenWidth = class_310.method_1551().method_22683().method_4486();
        int screenHeight = class_310.method_1551().method_22683().method_4502();

        if (renderX + totalWidth > screenWidth - 4) {
            renderX = mouseX - totalWidth - 4;
        }
        if (renderX < 4) {
            renderX = 4;
        }

        if (renderY + totalHeight > screenHeight - 4) {
            renderY = screenHeight - totalHeight - 4;
        }
        if (renderY < 4) {
            renderY = 4;
        }

        renderAt(context, renderX, renderY, totalWidth, totalHeight, delta);
    }

    protected void renderAt(class_332 context, int x, int y, int w, int h, float delta) {
        if (Renderer == null) {
            Renderer = new DefaultToolTipRenderer();
        }

        Renderer.render(context, 0, 0, delta, x, y, w, h, new RenderExtras()
                .with("backgroundColor", Integer.class,backgroundColor)
                .with("text", List.class, text));
    }

    public void setText(List<String> text) {
        this.text = text;
    }
}
