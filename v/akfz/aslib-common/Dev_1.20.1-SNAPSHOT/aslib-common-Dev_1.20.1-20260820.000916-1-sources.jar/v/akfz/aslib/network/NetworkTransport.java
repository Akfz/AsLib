package v.akfz.aslib.network;

import com.google.common.base.Preconditions;
import io.netty.buffer.Unpooled;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2658;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import v.akfz.aslib.network.api.Packet;
import v.akfz.aslib.network.registry.PacketRegistry;

public class NetworkTransport implements VanillaTransport {
    private final PacketRegistry registry;

    public NetworkTransport(PacketRegistry registry) {
        this.registry = registry;
    }

    @Override
    public void sendToServer(@NotNull Packet packet) {
        this.sendToServer(packet, this.createFriendlyByteBuf());
    }

    @Override
    public void sendToServer(@NotNull Packet packet, @NotNull class_2540 buf) {
        Preconditions.checkNotNull(packet);
        Preconditions.checkNotNull(buf);
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.method_1562() != null) {
            this.encodePacket(packet, buf);
            class_2817 customPacket = new class_2817(this.getId(packet), buf);
            mc.field_1724.field_3944.method_2883(customPacket);
        }
    }

    @Override
    public void sendToPlayer(@NotNull class_3222 player, @NotNull Packet packet) {
        this.sendToPlayer(player, packet, this.createFriendlyByteBuf());
    }

    @Override
    public void sendToPlayer(@NotNull class_3222 player, @NotNull Packet packet, @NotNull class_2540 buf) {
        Preconditions.checkNotNull(player);
        Preconditions.checkNotNull(packet);
        Preconditions.checkNotNull(buf);
        this.encodePacket(packet, buf);
        class_2658 customPacket = new class_2658(this.getId(packet), buf);
        player.field_13987.method_14364(customPacket);
    }

    public void sendToAll(@NotNull MinecraftServer server, @NotNull Packet packet) {
        Preconditions.checkNotNull(server);
        Preconditions.checkNotNull(packet);
        for (class_3222 player : server.method_3760().method_14571()) {
            this.sendToPlayer(player, packet);
        }
    }

    public void sendToLevel(@NotNull class_3218 level, @NotNull Packet packet) {
        Preconditions.checkNotNull(level);
        Preconditions.checkNotNull(packet);
        for (class_3222 player : level.method_18456()) {
            this.sendToPlayer(player, packet);
        }
    }

    public void sendToTracking(@NotNull class_1297 entity, @NotNull Packet packet) {
        Preconditions.checkNotNull(entity);
        Preconditions.checkNotNull(packet);
        if (entity.method_37908() instanceof class_3218 serverLevel) {
            for (class_3222 player : serverLevel.method_18456()) {
                if (serverLevel.method_14178().field_17254.method_17210(entity.method_31476(), false).contains(player)) {
                    this.sendToPlayer(player, packet);
                }
            }
        }
    }

    public void sendToAround(@NotNull class_3218 level, @NotNull class_243 pos, double radius, @NotNull Packet packet) {
        Preconditions.checkNotNull(level);
        Preconditions.checkNotNull(pos);
        Preconditions.checkNotNull(packet);
        double radiusSqr = radius * radius;
        for (class_3222 player : level.method_18456()) {
            if (player.method_5649(pos.field_1352, pos.field_1351, pos.field_1350) <= radiusSqr) {
                this.sendToPlayer(player, packet);
            }
        }
    }

    private void encodePacket(@NotNull Packet packet, @NotNull class_2540 buf) {
        try {
            AsLibNetworking.CODEC.encode(packet, buf);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class_2960 getId(Packet packet) {
        return this.registry.get(packet.getClass()).id();
    }

    private class_2540 createFriendlyByteBuf() {
        return new class_2540(Unpooled.buffer());
    }
}