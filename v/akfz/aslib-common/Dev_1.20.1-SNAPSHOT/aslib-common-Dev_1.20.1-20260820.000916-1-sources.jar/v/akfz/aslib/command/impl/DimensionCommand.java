package v.akfz.aslib.command.impl;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import v.akfz.aslib.command.CommandHelper;
import v.akfz.aslib.command.IRegCommand;
import v.akfz.aslib.world.DimensionBuilder;
import v.akfz.aslib.world.DimensionHelper;
import v.akfz.aslib.world.preset.VanillaBiomes;
import v.akfz.aslib.world.preset.VanillaNoiseSettings;

/**
 * Example + command for create and teleport to other dimensions\levels
 * (maybe work with others mod, who dont implementation aslib)
 */
public class DimensionCommand extends CommandHelper implements IRegCommand {

    @Override
    public void register(CommandDispatcher<class_2168> dispatcher) {

        var createVoidCmd = literal("create_void")
                .then(identifier("id")
                        .executes(ctx -> {
                            class_2960 id = getID(ctx, "id");

                            DimensionHelper.builder(id)
                                    .voidPreset()
                                    .register();

                            ctx.getSource().method_9226(() -> class_2561.method_43470("Created void dimension: " + id), true);
                            return 1;
                        }));

        var createFlatCmd = literal("create_flat")
                .then(identifier("id")
                        .executes(ctx -> {
                            class_2960 id = getID(ctx, "id");

                            DimensionHelper.builder(id)
                                    .generator(DimensionBuilder.GeneratorType.FLAT)
                                    .biome(VanillaBiomes.PLAINS)
                                    .enableStructures(false)
                                    .addLayer(new class_2960("minecraft", "bedrock"), 1)
                                    .addLayer(new class_2960("minecraft", "dirt"), 2)
                                    .addLayer(new class_2960("minecraft", "grass_block"), 1)
                                    .register();

                            ctx.getSource().method_9226(() -> class_2561.method_43470("Created flat dimension: " + id), true);
                            return 1;
                        }));

        var createNoiseCmd = literal("create_noise")
                .then(identifier("id")
                        .executes(ctx -> {
                            class_2960 id = getID(ctx, "id");

                            DimensionHelper.builder(id)
                                    .generator(DimensionBuilder.GeneratorType.NOISE)
                                    .biome(VanillaBiomes.PLAINS)
                                    .noiseSettings(VanillaNoiseSettings.OVERWORLD)
                                    .enableStructures(true)
                                    .register();

                            ctx.getSource().method_9226(() -> class_2561.method_43470("Created noise dimension: " + id), true);
                            return 1;
                        }));

        var tpCmd = literal("tp")
                .then(identifier("id")
                        .executes(ctx -> {
                            class_3222 player = ctx.getSource().method_9207();
                            class_2960 id = getID(ctx, "id");

                            class_3218 targetLevel = DimensionHelper.getLevel(player.method_37908(), id);
                            if (targetLevel == null) {
                                ctx.getSource().method_9213(class_2561.method_43470("Dimension is not loaded or does not exist: " + id));
                                return 0;
                            }

                            class_2338 spawn = targetLevel.method_43126();
                            double tpY = Math.max(spawn.method_10264(), -60.0);

                            DimensionHelper.teleport(player, targetLevel)
                                    .pos(spawn.method_10263() + 0.5, tpY, spawn.method_10260() + 0.5)
                                    .resetFall(true)
                                    .playSound(class_3417.field_14879)
                                    .execute();

                            ctx.getSource().method_9226(() -> class_2561.method_43470("Teleported to spawn of dimension: " + id), true);
                            return 1;
                        })
                        .then(integer("x").then(integer("y").then(integer("z")
                                .executes(ctx -> {
                                    class_3222 player = ctx.getSource().method_9207();
                                    class_2960 id = getID(ctx, "id");
                                    int x = getInt(ctx, "x");
                                    int y = getInt(ctx, "y");
                                    int z = getInt(ctx, "z");

                                    class_3218 targetLevel = DimensionHelper.getLevel(player.method_37908(), id);
                                    if (targetLevel == null) {
                                        ctx.getSource().method_9213(class_2561.method_43470("Dimension is not loaded: " + id));
                                        return 0;
                                    }

                                    DimensionHelper.teleport(player, targetLevel)
                                            .pos(x + 0.5, y, z + 0.5)
                                            .resetFall(true)
                                            .playSound(class_3417.field_14879)
                                            .execute();

                                    ctx.getSource().method_9226(() -> class_2561.method_43470("Teleported to " + id + " at coordinates " + x + ", " + y + ", " + z), true);
                                    return 1;
                                })))));

        var mainCmd = literal("aslib:dimension")
                .requires(hasLevel(2))
                .then(createVoidCmd)
                .then(createFlatCmd)
                .then(createNoiseCmd)
                .then(tpCmd);

        dispatcher.register(mainCmd);
    }
}