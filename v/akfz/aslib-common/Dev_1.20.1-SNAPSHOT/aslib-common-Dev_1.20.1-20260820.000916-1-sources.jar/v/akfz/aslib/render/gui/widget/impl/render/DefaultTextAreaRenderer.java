package v.akfz.aslib.render.gui.widget.impl.render;

import v.akfz.aslib.render.color.ColorUtils;
import v.akfz.aslib.render.gui.widget.api.render.RenderExtras;
import v.akfz.aslib.render.gui.widget.api.render.RenderPart;
import v.akfz.aslib.render.gui.widget.impl.text.helper.LineRenderer;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class DefaultTextAreaRenderer implements RenderPart {

    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float delta, int x, int y, int width, int height, RenderExtras extras) {
        String text = extras.getOrDefault("text", String.class, "");
        String placeholder = extras.getOrDefault("placeholder", String.class, "");
        int cursorPos = extras.getOrDefault("cursorPos", Integer.class, 0);
        int selStart = extras.getOrDefault("selStart", Integer.class, -1);
        int selEnd = extras.getOrDefault("selEnd", Integer.class, -1);
        int scrollX = extras.getOrDefault("scrollX", Integer.class, 0);
        int scrollY = extras.getOrDefault("scrollY", Integer.class, 0);
        boolean editable = extras.getOrDefault("editable", Boolean.class, true);
        boolean focused = extras.getOrDefault("focused", Boolean.class, false);
        boolean cursorVisible = extras.getOrDefault("cursorVisible", Boolean.class, true);
        LineRenderer lineRenderer = extras.get("lineRenderer", LineRenderer.class);
        float textScale = extras.getOrDefault("textScale", Float.class, 1.0f);

        int bgColor = ColorUtils.rgbToArgb(255, 30, 30, 30);
        int borderColor = focused ? ColorUtils.rgbToArgb(255, 140, 140, 140) : ColorUtils.rgbToArgb(255, 70, 70, 70);
        int txtColor = editable ? 0xE0E0E0 : 0xA0A0A0;
        int placeholderColor = 0x808080;
        int selectionColor = ColorUtils.rgbToArgb(100, 0, 120, 215);
        int cursorColor = 0xFFFFFFFF;

        class_327 font = class_310.method_1551().field_1772;

        graphics.method_25294(x, y, x + width, y + height, bgColor);
        graphics.method_49601(x, y, width, height, borderColor);

        if (text.isEmpty() && !focused && !placeholder.isEmpty()) {
            graphics.method_51433(font, placeholder, x + 5, y + 4, placeholderColor, false);
            return;
        }

        List<String> lines = new ArrayList<>();
        if (text.isEmpty()) {
            lines.add("");
        } else {
            lines.addAll(List.of(text.split("\n", -1)));
        }

        int cursorLine = -1;
        int cursorCol = -1;
        int remaining = cursorPos;
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (remaining <= line.length()) {
                cursorLine = i;
                cursorCol = remaining;
                break;
            }
            remaining -= line.length() + 1;
        }
        if (cursorLine == -1 && !lines.isEmpty()) {
            cursorLine = lines.size() - 1;
            cursorCol = lines.get(cursorLine).length();
        }

        Vector4f scissorPos1 = new Vector4f((float) (x + 3), (float) (y + 3), 0.0F, 1.0F);
        Vector4f scissorPos2 = new Vector4f((float) (x + width - 3), (float) (y + height - 3), 0.0F, 1.0F);

        scissorPos1.mul(graphics.method_51448().method_23760().method_23761());
        scissorPos2.mul(graphics.method_51448().method_23760().method_23761());

        graphics.method_44379(
                Math.round(scissorPos1.x()),
                Math.round(scissorPos1.y()),
                Math.round(scissorPos2.x()),
                Math.round(scissorPos2.y())
        );

        class_4587 poseStack = graphics.method_51448();
        poseStack.method_22903();

        poseStack.method_46416(x + 4 - (scrollX / textScale), y + 2 - (scrollY / textScale), 0);
        poseStack.method_22905(textScale, textScale, 1.0f);

        int currentGlobalIdx = 0;
        int localLineHeight = font.field_2000 + 2;

        int selMin = Math.min(selStart, selEnd);
        int selMax = Math.max(selStart, selEnd);
        boolean hasSel = selStart != -1 && selEnd != -1 && selStart != selEnd;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            int lineLen = line.length();
            int lineY = i * localLineHeight;

            if (hasSel) {
                int lineMin = currentGlobalIdx;
                int lineMax = currentGlobalIdx + lineLen;

                if (!(lineMax < selMin || lineMin > selMax)) {
                    int startSelCol = Math.max(0, selMin - lineMin);
                    int endSelCol = Math.min(lineLen, selMax - lineMin);

                    int selX1 = font.method_1727(line.substring(0, startSelCol));
                    int selX2 = font.method_1727(line.substring(0, endSelCol));

                    if (selMax > lineMax && endSelCol == lineLen) {
                        selX2 += 4;
                    }

                    if (selX1 != selX2) {
                        graphics.method_25294(selX1, lineY, selX2, lineY + font.field_2000, selectionColor);
                    }
                }
            }

            if (lineRenderer != null) {
                lineRenderer.render(graphics, line, 0, lineY, i, currentGlobalIdx, txtColor);
            } else {
                graphics.method_51433(font, line, 0, lineY, txtColor, false);
            }

            if (focused && cursorVisible && editable && i == cursorLine) {
                String lineBeforeCursor = line.substring(0, cursorCol);
                int cursorX = font.method_1727(lineBeforeCursor);

                poseStack.method_22903();
                poseStack.method_46416(0, 0, 1.0f);

                graphics.method_25301(cursorX, lineY - 1, lineY + font.field_2000, cursorColor);

                poseStack.method_22909();
            }

            currentGlobalIdx += lineLen + 1;
        }

        poseStack.method_22909();
        graphics.method_44380();
    }
}