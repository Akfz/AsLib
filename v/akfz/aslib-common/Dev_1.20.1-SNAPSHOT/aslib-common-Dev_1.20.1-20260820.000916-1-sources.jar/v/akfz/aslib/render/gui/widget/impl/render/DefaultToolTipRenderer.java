package v.akfz.aslib.render.gui.widget.impl.render;

import v.akfz.aslib.render.color.ColorUtils;
import v.akfz.aslib.render.gui.widget.api.render.RenderExtras;
import v.akfz.aslib.render.gui.widget.api.render.RenderPart;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class DefaultToolTipRenderer implements RenderPart {
    @SuppressWarnings("unchecked")
    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float delta, int x, int y, int width, int height, RenderExtras extras) {
        int bgColor = (int) extras.get("backgroundColor", Integer.class);
        List<String> lines = (List<String>) extras.get("text",List.class);
        if (lines == null || lines.isEmpty())
            return;

        graphics.method_25294(x, y, x + width, y + height, bgColor);
        graphics.method_49601(x, y, width, height, ColorUtils.rgbToArgb(115));

        class_327 font = class_310.method_1551().field_1772;
        int padding = 4;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            int lineX = x + padding;
            int lineY = y + padding + (i * (font.field_2000 + 2));
            graphics.method_51439(font, class_2561.method_43470(line), lineX, lineY, ColorUtils.white(), true);
        }
    }
}
