package v.akfz.aslib.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;

/**
 * like in fabric-api or forge (literally)
 */
public interface IRegCommand {
    void register(CommandDispatcher<class_2168> dispatcher);
}
