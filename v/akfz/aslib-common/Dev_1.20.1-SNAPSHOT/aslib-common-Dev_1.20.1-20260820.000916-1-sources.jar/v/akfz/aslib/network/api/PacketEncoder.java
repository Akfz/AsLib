package v.akfz.aslib.network.api;

import net.minecraft.class_2540;

@FunctionalInterface
public interface PacketEncoder<T extends Packet> {
    void encode(T packet, class_2540 buf);
}
