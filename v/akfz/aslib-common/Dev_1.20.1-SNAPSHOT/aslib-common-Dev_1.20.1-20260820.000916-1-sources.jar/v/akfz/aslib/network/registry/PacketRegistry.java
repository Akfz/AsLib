package v.akfz.aslib.network.registry;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2960;
import v.akfz.aslib.network.annotation.NetworkPacket;
import v.akfz.aslib.network.api.Packet;
import v.akfz.aslib.network.api.PacketDecoder;
import v.akfz.aslib.network.api.PacketEncoder;
import v.akfz.aslib.network.api.PacketHandler;

/**
 * Thread-safe registry for managing network packets, their codecs, and handlers.
 */
public final class PacketRegistry {
    private final Map<class_2960, PacketEntry<?>> byId = new ConcurrentHashMap<>();
    private final Map<Class<? extends Packet>, PacketEntry<?>> byClass = new ConcurrentHashMap<>();

    /**
     * Registers a packet with explicit encoder, decoder, and handler.
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public <T extends Packet> void register(Class<T> type, PacketEncoder<T> encoder, PacketDecoder<T> decoder, PacketHandler<T> handler) {
        class_2960 resourceLocation = this.getResourceLocation(type);
        if (resourceLocation == null) {
            throw new IllegalArgumentException("ResourceLocation is missing on class: " + type.getName());
        } else {
            this.register(new PacketEntry(resourceLocation, type, encoder, decoder, handler));
        }
    }

    /**
     * Registers a packet using its internal encoder/decoder implementation.
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public <T extends Packet> void register(T dummyInstance, PacketHandler<T> handler) {
        class_2960 resourceLocation = this.getResourceLocation(dummyInstance.getClass());
        if (resourceLocation == null) {
            throw new IllegalArgumentException("ResourceLocation is missing on class: " + dummyInstance.getClass().getName());
        } else {
            this.register(new PacketEntry(resourceLocation, dummyInstance, handler));
        }
    }

    public <T extends Packet> void register(PacketEntry<T> entry) {
        if (this.byId.containsKey(entry.id())) {
            throw new IllegalStateException("Duplicate packet id: " + entry.id());
        } else if (this.byClass.containsKey(entry.type())) {
            throw new IllegalStateException("Packet already registered: " + entry.type().getName());
        } else {
            this.byId.put(entry.id(), entry);
            this.byClass.put(entry.type(), entry);
        }
    }

    private class_2960 getResourceLocation(Class<? extends Packet> clazz) {
        if (clazz.isAnnotationPresent(NetworkPacket.class)) {
            NetworkPacket annotation = clazz.getAnnotation(NetworkPacket.class);
            return class_2960.method_12829(annotation.value());
        }
        return null;
    }

    public boolean isPresent(class_2960 id) {
        return this.byId.containsKey(id);
    }

    public boolean isPresent(Class<?> type) {
        return this.byClass.containsKey(type);
    }

    public PacketEntry<?> get(class_2960 id) {
        return this.byId.get(id);
    }

    public PacketEntry<?> get(Class<?> type) {
        return this.byClass.get(type);
    }
}