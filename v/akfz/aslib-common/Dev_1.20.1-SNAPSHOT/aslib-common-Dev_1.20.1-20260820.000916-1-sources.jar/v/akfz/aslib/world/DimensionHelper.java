package v.akfz.aslib.world;

import net.minecraft.class_1297;
import net.minecraft.class_156;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_1992;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_27;
import net.minecraft.class_2780;
import net.minecraft.class_2794;
import net.minecraft.class_2806;
import net.minecraft.class_2874;
import net.minecraft.class_2897;
import net.minecraft.class_2960;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3229;
import net.minecraft.class_3232;
import net.minecraft.class_3754;
import net.minecraft.class_3949;
import net.minecraft.class_4543;
import net.minecraft.class_5284;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7059;
import net.minecraft.class_7871;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.biome.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

/**
 * Utility class for dimension management, runtime level creation, and cross-dimensional entity teleportation.
 */
public final class DimensionHelper {

    private static final Map<class_2960, DimensionConfig> CONFIG_MAP = new ConcurrentHashMap<>();

    private DimensionHelper() {}

    /**
     * Stores internal configuration for dynamic level generation.
     */
    public static void registerConfig(class_2960 id, DimensionBuilder.GeneratorType type, class_2960 biome, List<DimensionBuilder.LayerEntry> layers, class_2960 noiseSettings, boolean enableStructures) {
        CONFIG_MAP.put(id, new DimensionConfig(type, biome, new ArrayList<>(layers), noiseSettings, enableStructures));
    }

    /**
     * Creates a new {@link DimensionBuilder} for the specified identifier.
     */
    public static DimensionBuilder builder(class_2960 dimensionId) {
        return DimensionBuilder.create(dimensionId);
    }

    /**
     * Registers a void dimension with default settings.
     */
    public static class_5321<class_1937> registerVoid(class_2960 dimensionId) {
        return builder(dimensionId).voidPreset().register();
    }

    /**
     * Initiates a fluent teleport builder for an entity.
     *
     * @param entity      Target entity to teleport.
     * @param targetLevel Target ServerLevel destination.
     * @return New TeleportBuilder instance.
     */
    public static TeleportBuilder teleport(class_1297 entity, class_3218 targetLevel) {
        return new TeleportBuilder(entity, targetLevel);
    }

    /**
     * Retrieves an existing ServerLevel or dynamically instantiates and registers a new ServerLevel at runtime.
     *
     * @param server      Server instance.
     * @param dimensionId Dimension ResourceLocation identifier.
     * @return Active {@link class_3218} instance.
     */
    public static class_3218 getOrCreateLevel(MinecraftServer server, class_2960 dimensionId) {
        if (server == null || dimensionId == null) return null;

        class_5321<class_1937> key = class_5321.method_29179(class_7924.field_41223, dimensionId);
        class_3218 existing = server.method_3847(key);
        if (existing != null) {
            return existing;
        }

        try {
            class_3218 overworld = server.method_30002();
            DimensionConfig config = CONFIG_MAP.get(dimensionId);

            class_2794 chunkGenerator;

            if (config != null && config.generatorType == DimensionBuilder.GeneratorType.NOISE) {
                class_2960 noiseKey = config.noiseSettings != null ? config.noiseSettings : class_5284.field_26355.method_29177();
                class_2960 biomeKey = config.biome != null ? config.biome : class_1972.field_9451.method_29177();

                class_7871<class_5284> noiseRegistry = server.method_30611().method_46762(class_7924.field_41243);
                class_6880<class_5284> noiseHolder = noiseRegistry.method_46747(class_5321.method_29179(class_7924.field_41243, noiseKey));

                class_7871<class_1959> biomeRegistry = server.method_30611().method_46762(class_7924.field_41236);
                class_6880<class_1959> biomeHolder = biomeRegistry.method_46747(class_5321.method_29179(class_7924.field_41236, biomeKey));

                chunkGenerator = new class_3754(new class_1992(biomeHolder), noiseHolder);

            } else {
                class_2960 biomeKey = (config != null && config.biome != null) ? config.biome : class_1972.field_9473.method_29177();

                class_7871<class_1959> biomeRegistry = server.method_30611().method_46762(class_7924.field_41236);
                class_6880<class_1959> biomeHolder = biomeRegistry.method_46746(class_5321.method_29179(class_7924.field_41236, biomeKey))
                        .orElseGet(() -> biomeRegistry.method_46747(class_1972.field_9473));

                Optional<class_6885<class_7059>> structureOverrides = (config != null && config.enableStructures)
                        ? Optional.empty()
                        : Optional.of(class_6885.method_40246());

                class_3232 flatSettings = new class_3232(
                        structureOverrides,
                        biomeHolder,
                        List.of()
                );

                if (config != null && !config.flatLayers.isEmpty()) {
                    for (DimensionBuilder.LayerEntry layer : config.flatLayers) {
                        class_2248 block = class_7923.field_41175.method_10223(layer.blockId());
                        if (block != null) {
                            flatSettings.method_14327().add(new class_3229(layer.height(), block));
                        }
                    }
                } else {
                    flatSettings.method_14327().add(new class_3229(1, class_2246.field_10124));
                }

                chunkGenerator = new class_2897(flatSettings);
            }

            class_6880<class_2874> dimTypeHolder = overworld.method_40134();
            class_5363 levelStem = new class_5363(dimTypeHolder, chunkGenerator);

            class_32.class_5143 storageAccess = ((MinecraftServerExtension) server).aslib$getStorageSource();
            Executor backgroundExecutor = class_156.method_18349();
            class_27 levelData = new class_27(server.method_27728(), server.method_27728().method_27859());

            class_3218 newLevel = new class_3218(
                    server,
                    backgroundExecutor,
                    storageAccess,
                    levelData,
                    key,
                    levelStem,
                    new class_3949() {
                        @Override public void method_17669(class_1923 spawnPos) {}
                        @Override public void method_17670(class_1923 chunkPosition, class_2806 newStatus) {}
                        @Override public void method_17675() {}
                        @Override public void method_17671() {}
                    },
                    false,
                    class_4543.method_27984(server.method_27728().method_28057().method_28028()),
                    List.of(),
                    true,
                    overworld.method_52168()
            );

            overworld.method_8621().method_11983(new class_2780.class_3976(newLevel.method_8621()));

            Map<class_5321<class_1937>, class_3218> levelsMap = ((MinecraftServerExtension) server).aslib$getLevels();
            levelsMap.put(key, newLevel);

            return newLevel;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Gets or creates a level from an existing level context.
     */
    public static class_3218 getLevel(class_1937 currentLevel, class_2960 dimensionId) {
        if (currentLevel != null && currentLevel.method_8503() != null) {
            return getOrCreateLevel(currentLevel.method_8503(), dimensionId);
        }
        return null;
    }

    private record DimensionConfig(
            DimensionBuilder.GeneratorType generatorType,
            class_2960 biome,
            List<DimensionBuilder.LayerEntry> flatLayers,
            class_2960 noiseSettings,
            boolean enableStructures
    ) {}
}