package v.akfz.aslib.network.api;

import net.minecraft.class_2596;
import net.minecraft.class_3222;

public interface NetworkManager {
    void sendToServer(class_2596 packet);

    void sendToPlayer(class_3222 player, class_2596 packet);
}

