package v.akfz.aslib.datagen.sound;


import java.util.List;
import java.util.Optional;
import net.minecraft.class_2960;

/**
 *  soundID is the sound ID (like aslib:test), while sounds represents all the possible sounds that will be played (seemingly at random).
 */
public record SoundDataEntry(class_2960 soundID, Optional<String> subtitle, List<class_2960> sounds){}
