package v.akfz.aslib.world;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

/**
 * Fluent builder for executing entity teleportation across positions and dimensions.
 */
public class TeleportBuilder {
    private final class_1297 entity;
    private final class_3218 targetLevel;
    private class_243 pos = class_243.field_1353;
    private float yaw = 0.0f;
    private float pitch = 0.0f;

    private boolean resetFallDistance = true;
    private boolean keepVelocity = false;
    private class_3414 sound = null;

    public TeleportBuilder(class_1297 entity, class_3218 targetLevel) {
        this.entity = entity;
        this.targetLevel = targetLevel;
        if (entity != null) {
            this.pos = entity.method_19538();
            this.yaw = entity.method_36454();
            this.pitch = entity.method_36455();
        }
    }

    /**
     * Sets target coordinates.
     */
    public TeleportBuilder pos(double x, double y, double z) {
        this.pos = new class_243(x, y, z);
        return this;
    }

    /**
     * Sets target position vector.
     */
    public TeleportBuilder pos(class_243 pos) {
        if (pos != null) this.pos = pos;
        return this;
    }

    /**
     * Sets target yaw and pitch rotation.
     */
    public TeleportBuilder rot(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
        return this;
    }

    /**
     * Sets whether fall distance should be reset to zero upon teleportation.
     */
    public TeleportBuilder resetFall(boolean reset) {
        this.resetFallDistance = reset;
        return this;
    }

    /**
     * Sets whether entity velocity should be preserved after teleportation.
     */
    public TeleportBuilder keepVelocity(boolean keep) {
        this.keepVelocity = keep;
        return this;
    }

    /**
     * Sets a sound event to play at destination.
     */
    public TeleportBuilder playSound(class_3414 sound) {
        this.sound = sound;
        return this;
    }

    /**
     * Executes teleportation.
     *
     * @return Teleported entity instance (may differ if dimension change recreates entity).
     */
    public class_1297 execute() {
        if (entity == null || targetLevel == null) return null;

        class_243 velocity = entity.method_18798();

        if (resetFallDistance) {
            entity.method_38785();
        }

        class_1297 resultEntity;

        if (entity instanceof class_3222 player) {
            player.method_14251(targetLevel, pos.field_1352, pos.field_1351, pos.field_1350, yaw, pitch);
            resultEntity = player;
        } else {
            if (entity.method_37908() != targetLevel) {
                entity.method_5859(pos.field_1352, pos.field_1351, pos.field_1350);
                entity.method_36456(yaw);
                entity.method_36457(pitch);
                resultEntity = entity.method_5731(targetLevel);
            } else {
                entity.method_5859(pos.field_1352, pos.field_1351, pos.field_1350);
                entity.method_36456(yaw);
                entity.method_36457(pitch);
                resultEntity = entity;
            }
        }

        if (resultEntity != null) {
            if (keepVelocity) {
                resultEntity.method_18799(velocity);
            } else {
                resultEntity.method_18799(class_243.field_1353);
            }

            if (sound != null) {
                targetLevel.method_43128(
                        null,
                        pos.field_1352, pos.field_1351, pos.field_1350,
                        sound,
                        class_3419.field_15248,
                        1.0f, 1.0f
                );
            }
        }

        return resultEntity;
    }
}