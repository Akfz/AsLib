package v.akfz.aslib.mixin;

import net.minecraft.class_2535;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_3244.class})
public interface SrvGamePacketListenerAccessor {
    @Accessor("connection")
    class_2535 getConnection();
}
