package v.akfz.aslib.datagen.api;

import net.minecraft.class_2960;

/**
 * its {@link DataSerializable}, but String instead of JsonElement
 */
public abstract class DataStringSerializable implements Serializable<String> {
    private final class_2960 path;

    public DataStringSerializable(class_2960 path) {
        this.path = path;
    }

    @Override
    public class_2960 getRLPath() {
        return this.path;
    }

    @Override
    public abstract String serialize();
}
