package v.akfz.aslib.util.math;

import net.minecraft.class_238;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

/**
 * 3D math utilities for raycasts, screen projections, and intersections
 */
public final class Math3D {

    /**
     * Finds the closest point on a ray to the target point in 3D space
     */
    public static class_243 getClosestPointOnRay(class_243 rayOrigin, class_243 rayDirection, class_243 targetPoint) {
        class_243 toTarget = targetPoint.method_1020(rayOrigin);
        double t = toTarget.method_1026(rayDirection);
        if (t < 0.0) {
            return rayOrigin;
        }
        return rayOrigin.method_1019(rayDirection.method_1021(t));
    }

    /**
     * Calculates ray-sphere intersection. Returns distance to hit point or -1 if missed
     */
    public static double intersectRaySphere(class_243 rayOrigin, class_243 rayDir, class_243 sphereCenter, double sphereRadius) {
        class_243 oc = rayOrigin.method_1020(sphereCenter);
        double b = oc.method_1026(rayDir);
        double c = oc.method_1026(oc) - (sphereRadius * sphereRadius);
        double h = b * b - c;
        if (h < 0.0) return -1.0;
        h = Math.sqrt(h);
        double t0 = -b - h;
        if (t0 >= 0.0) return t0;
        double t1 = -b + h;
        if (t1 >= 0.0) return t1;
        return -1.0;
    }

    /**
     * Calculates ray-AABB (bounding box) intersection. Returns distance or -1 if missed
     */
    public static double intersectRayAABB(class_243 rayOrigin, class_243 rayDir, class_238 aabb) {
        double tmin = Double.NEGATIVE_INFINITY;
        double tmax = Double.POSITIVE_INFINITY;

        if (Math.abs(rayDir.field_1352) > 1e-6) {
            double tx1 = (aabb.field_1323 - rayOrigin.field_1352) / rayDir.field_1352;
            double tx2 = (aabb.field_1320 - rayOrigin.field_1352) / rayDir.field_1352;
            tmin = Math.max(tmin, Math.min(tx1, tx2));
            tmax = Math.min(tmax, Math.max(tx1, tx2));
        } else if (rayOrigin.field_1352 < aabb.field_1323 || rayOrigin.field_1352 > aabb.field_1320) {
            return -1.0;
        }

        if (Math.abs(rayDir.field_1351) > 1e-6) {
            double ty1 = (aabb.field_1322 - rayOrigin.field_1351) / rayDir.field_1351;
            double ty2 = (aabb.field_1325 - rayOrigin.field_1351) / rayDir.field_1351;
            tmin = Math.max(tmin, Math.min(ty1, ty2));
            tmax = Math.min(tmax, Math.max(ty1, ty2));
        } else if (rayOrigin.field_1351 < aabb.field_1322 || rayOrigin.field_1351 > aabb.field_1325) {
            return -1.0;
        }

        if (Math.abs(rayDir.field_1350) > 1e-6) {
            double tz1 = (aabb.field_1321 - rayOrigin.field_1350) / rayDir.field_1350;
            double tz2 = (aabb.field_1324 - rayOrigin.field_1350) / rayDir.field_1350;
            tmin = Math.max(tmin, Math.min(tz1, tz2));
            tmax = Math.min(tmax, Math.max(tz1, tz2));
        } else if (rayOrigin.field_1350 < aabb.field_1321 || rayOrigin.field_1350 > aabb.field_1324) {
            return -1.0;
        }

        if (tmax >= tmin && tmax >= 0.0) {
            return Math.max(tmin, 0.0);
        }
        return -1.0;
    }

    /**
     * Converts 2D screen mouse coordinates into a normalized 3D world ray
     */
    public static class_243 getRayFromScreen(double mouseX, double mouseY, int screenWidth, int screenHeight, Matrix4f invProj, Matrix4f invView) {
        float ndcX = (float) ((2.0 * mouseX) / screenWidth - 1.0);
        float ndcY = (float) (1.0 - (2.0 * mouseY) / screenHeight);

        Vector4f rayClip = new Vector4f(ndcX, ndcY, -1.0f, 1.0f);

        Vector4f rayEye = invProj.transform(rayClip, new Vector4f());
        rayEye.z = -1.0f;
        rayEye.w = 0.0f;

        Vector4f rayWorld = invView.transform(rayEye, new Vector4f());

        return new class_243(rayWorld.x(), rayWorld.y(), rayWorld.z()).method_1029();
    }

    /**
     * Projects a 3D world position to 2D screen coordinates. Returns null if behind camera
     */
    @Nullable
    public static Vector3f worldToScreen(class_243 worldPos, class_243 cameraPos, Matrix4f viewProjMatrix, int screenWidth, int screenHeight) {
        class_243 relativePos = worldPos.method_1020(cameraPos);
        Vector4f clipSpace = new Vector4f((float) relativePos.field_1352, (float) relativePos.field_1351, (float) relativePos.field_1350, 1.0f);

        viewProjMatrix.transform(clipSpace);

        if (clipSpace.w() <= 0.0f) {
            return null;
        }

        float ndcX = clipSpace.x() / clipSpace.w();
        float ndcY = clipSpace.y() / clipSpace.w();
        float ndcZ = clipSpace.z() / clipSpace.w();

        float screenX = ((ndcX + 1.0f) / 2.0f) * screenWidth;
        float screenY = ((1.0f - ndcY) / 2.0f) * screenHeight;

        return new Vector3f(screenX, screenY, ndcZ);
    }

    /**
     * Converts yaw and pitch angles into a 3D direction vector
     */
    public static class_243 getDirectionFromRotation(float yaw, float pitch) {
        float radPitch = pitch * ((float) Math.PI / 180.0F);
        float radYaw = -yaw * ((float) Math.PI / 180.0F);
        float cosYaw = (float) Math.cos(radYaw);
        float sinYaw = (float) Math.sin(radYaw);
        float cosPitch = (float) Math.cos(radPitch);
        float sinPitch = (float) Math.sin(radPitch);
        return new class_243(sinYaw * cosPitch, -sinPitch, cosYaw * cosPitch);
    }
}