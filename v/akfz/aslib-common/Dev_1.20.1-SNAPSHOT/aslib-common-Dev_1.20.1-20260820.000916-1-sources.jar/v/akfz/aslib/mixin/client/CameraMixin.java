package v.akfz.aslib.mixin.client;

import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import v.akfz.aslib.render.camera.CameraExtender;
import v.akfz.aslib.render.camera.CameraManager;
import v.akfz.aslib.util.math.MathFormulas;

@Mixin(class_4184.class)
public class CameraMixin implements CameraExtender {
    @Unique private class_243 specPos = class_243.field_1353;
    @Unique private class_243 specRot = class_243.field_1353;
    @Unique private boolean customRotsOnned = true;

    @Unique private static long lastFrameTime = System.nanoTime();

    @Shadow protected void setPosition(double x, double y, double z) {}

    @Shadow private float eyeHeight;
    @Shadow private float eyeHeightOld;

    @Final @Shadow private Vector3f forwards;
    @Final @Shadow private Vector3f up;
    @Final @Shadow private Vector3f left;

    @Shadow private float xRot;
    @Shadow private float yRot;
    @Unique private float roll;
    @Final @Shadow private Quaternionf rotation;

    @Unique private double currentSmoothX, currentSmoothY, currentSmoothZ;
    @Unique private float currentSmoothRotX, currentSmoothRotY, currentSmoothRotZ;

    @Inject(method = "setup", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setPosition(DDD)V", shift = At.Shift.AFTER))
    public void onSetup(class_1922 level, class_1297 entity, boolean detached, boolean thirdPersonReverse, float partialTick, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();

        if (mc.field_1687 == null || mc.field_1724 == null || entity == null) {
            lastFrameTime = System.nanoTime();
            return;
        }

        long now = System.nanoTime();
        double dtInSeconds = (now - lastFrameTime) / 1_000_000_000.0;
        lastFrameTime = now;

        if (dtInSeconds <= 0.0 || dtInSeconds > 0.1) {
            dtInSeconds = 0.016;
        }

        float dt = (float) (dtInSeconds / 0.05);
        boolean isTethered = specPos != null && specPos.method_1027() > 1e-4;

        if (isTethered) {
            double x = class_3532.method_16436((double) partialTick, entity.field_6014, entity.method_23317());
            double y = class_3532.method_16436((double) partialTick, entity.field_6036, entity.method_23318())
                    + class_3532.method_16436((double) partialTick, this.eyeHeightOld, this.eyeHeight);
            double z = class_3532.method_16436((double) partialTick, entity.field_5969, entity.method_23321());

            currentSmoothX = MathFormulas.exponentialSmooth(currentSmoothX, specPos.field_1352, CameraManager.posSpeed, dt);
            currentSmoothY = MathFormulas.exponentialSmooth(currentSmoothY, specPos.field_1351, CameraManager.posSpeed, dt);
            currentSmoothZ = MathFormulas.exponentialSmooth(currentSmoothZ, specPos.field_1350, CameraManager.posSpeed, dt);

            this.setPosition(x + currentSmoothX, y + currentSmoothY, z + currentSmoothZ);

            float basePitch = xRot;
            float baseYaw = yRot;

            boolean hasCustomRots = customRotsOnned && specRot != null && specRot.method_1027() > 1e-4;

            if (hasCustomRots) {
                currentSmoothRotX = (float) MathFormulas.exponentialSmooth(currentSmoothRotX, (float) specRot.field_1352, CameraManager.rotSpeed, dt);
                currentSmoothRotY = (float) MathFormulas.exponentialSmooth(currentSmoothRotY, (float) specRot.field_1351, CameraManager.rotSpeed, dt);
                currentSmoothRotZ = (float) MathFormulas.exponentialSmooth(currentSmoothRotZ, (float) specRot.field_1350, CameraManager.rotSpeed, dt);

                this.xRot += currentSmoothRotX;
                this.yRot += currentSmoothRotY;
                this.roll = currentSmoothRotZ;

                this.yRot = class_3532.method_15393(this.yRot);
                this.xRot = class_3532.method_15363(this.xRot, -90.0f, 90.0f);
            } else {
                this.xRot = basePitch;
                this.yRot = baseYaw;
                this.roll = 0.0f;
            }

            this.rotation.rotationYXZ(
                    (float) Math.toRadians(-yRot),
                    (float) Math.toRadians(xRot),
                    (float) Math.toRadians(-roll)
            );
            this.forwards.set(0.0F, 0.0F, 1.0F).rotate(this.rotation);
            this.up.set(0.0F, 1.0F, 0.0F).rotate(this.rotation);
            this.left.set(1.0F, 0.0F, 0.0F).rotate(this.rotation);

        } else if (customRotsOnned && specRot != null && specRot.method_1027() > 1e-4) {
            currentSmoothRotZ = (float) MathFormulas.exponentialSmooth(currentSmoothRotZ, (float) specRot.field_1350, CameraManager.rotSpeed, dt);
            this.roll = currentSmoothRotZ;

            this.rotation.rotationYXZ(
                    (float) Math.toRadians(-yRot),
                    (float) Math.toRadians(xRot),
                    (float) Math.toRadians(-roll)
            );
            this.forwards.set(0.0F, 0.0F, 1.0F).rotate(this.rotation);
            this.up.set(0.0F, 1.0F, 0.0F).rotate(this.rotation);
            this.left.set(1.0F, 0.0F, 0.0F).rotate(this.rotation);
        }
    }

    @Override
    public void addPos(class_243 pos) {
        this.specPos = pos;
    }

    @Override
    public void addRot(class_243 rot) {
        this.specRot = rot;
    }

    @Override
    public class_243 getRot() {
        return this.specRot;
    }

    @Override
    public void clearRots() {
        this.specRot = class_243.field_1353;
    }

    @Override
    public void clearPos() {
        this.specPos = class_243.field_1353;
    }

    @Override
    public void setCustomRotsOnned(boolean customRotsOnned) {
        this.customRotsOnned = customRotsOnned;
    }

    @Override
    public float getRoll() {
        return this.roll;
    }
}