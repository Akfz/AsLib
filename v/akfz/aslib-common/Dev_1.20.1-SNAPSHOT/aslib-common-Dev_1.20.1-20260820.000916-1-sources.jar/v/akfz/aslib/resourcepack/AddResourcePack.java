package v.akfz.aslib.resourcepack;

import net.minecraft.class_155;
import net.minecraft.class_2561;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_5352;
import net.minecraft.class_7699;

/**
 * Utility class for injecting custom resource packs and data packs into a Minecraft {@link class_3283}.
 */
public final class AddResourcePack {

    private AddResourcePack() {}

    /**
     * Registers a client resource pack.
     */
    public static void add(class_3283 manager, class_3262 pack, class_2561 description,
                           String id, class_2561 displayName, boolean alwaysEnabled,
                           class_3288.class_3289 pos, boolean pinned, class_5352 source) {
        add(manager, pack, description, id, displayName, alwaysEnabled, pos, pinned, source, class_3264.field_14188);
    }

    /**
     * Registers a file-system backed client resource pack.
     */
    public static void addFRP(class_3283 manager, FileResourcePack frp, class_2561 description,
                              boolean alwaysEnabled, class_3288.class_3289 pos,
                              boolean pinned, class_5352 source) {
        addFRP(manager, frp, description, alwaysEnabled, pos, pinned, source, class_3264.field_14188);
    }

    /**
     * Registers a pack with a custom {@link class_3264}.
     */
    public static void add(class_3283 manager, class_3262 pack, class_2561 description,
                           String id, class_2561 displayName, boolean alwaysEnabled,
                           class_3288.class_3289 pos, boolean pinned, class_5352 source, class_3264 packType) {
        registerInternal(manager, id, displayName, alwaysEnabled, pos, pinned, source, description, name -> pack, packType);
    }

    /**
     * Registers a file-system backed pack with a custom {@link class_3264}.
     */
    public static void addFRP(class_3283 manager, FileResourcePack frp, class_2561 description,
                              boolean alwaysEnabled, class_3288.class_3289 pos,
                              boolean pinned, class_5352 source, class_3264 packType) {
        registerInternal(manager, frp.getSimpleNamespace(), class_2561.method_43470(frp.getPack().method_14409()),
                alwaysEnabled, pos, pinned, source, description, name -> frp.getPack(), packType);
    }

    /**
     * Registers a server data pack.
     */
    public static void addServerData(class_3283 manager, class_3262 pack, class_2561 description,
                                     String id, class_2561 displayName, boolean alwaysEnabled,
                                     class_3288.class_3289 pos, boolean pinned, class_5352 source) {
        add(manager, pack, description, id, displayName, alwaysEnabled, pos, pinned, source, class_3264.field_14190);
    }

    /**
     * Registers a file-system backed server data pack.
     */
    public static void addServerDataFRP(class_3283 manager, FileResourcePack frp, class_2561 description,
                                        boolean alwaysEnabled, class_3288.class_3289 pos,
                                        boolean pinned, class_5352 source) {
        addFRP(manager, frp, description, alwaysEnabled, pos, pinned, source, class_3264.field_14190);
    }

    private static void registerInternal(class_3283 manager, String id, class_2561 name,
                                         boolean alwaysEnabled, class_3288.class_3289 pos,
                                         boolean pinned, class_5352 source, class_2561 description,
                                         class_3288.class_7680 factory, class_3264 packType) {

        if (manager instanceof ResourcePackExpander r) {
            r.addProvider(profileAdder -> {
                int currentFormat = class_155.method_16673().method_48017(packType);

                class_3288.class_7679 metadata = new class_3288.class_7679(
                        description,
                        currentFormat,
                        class_7699.method_45397()
                );

                class_5352 finalSource = alwaysEnabled ? new class_5352() {
                    @Override
                    public class_2561 method_45282(class_2561 packName) {
                        return source.method_45282(packName);
                    }

                    @Override
                    public boolean method_45279() {
                        return true;
                    }
                } : source;

                boolean isFixed = alwaysEnabled || pinned;

                class_3288 profile = class_3288.method_14456(
                        id,
                        name,
                        alwaysEnabled,
                        factory,
                        metadata,
                        packType,
                        pos,
                        isFixed,
                        finalSource
                );

                if (profile != null) {
                    profileAdder.accept(profile);
                }
            });
        }
    }
}