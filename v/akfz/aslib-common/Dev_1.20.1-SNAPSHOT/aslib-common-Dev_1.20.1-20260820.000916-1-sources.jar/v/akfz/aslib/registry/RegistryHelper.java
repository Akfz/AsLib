package v.akfz.aslib.registry;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.function.Supplier;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_4970;

/**
 * Utility class providing helper methods for instantiating Minecraft registry objects
 * such as entities, block entities, sound events, properties, and creative tabs.
 */
public final class RegistryHelper {

    private RegistryHelper() {}

    private static final Class<?> SUPPLIER_CLASS;
    private static final Method OF_METHOD;

    static {
        Class<?> tempClass = null;
        Method tempMethod = null;
        try {
            String[] possibleNames = {
                    "net.minecraft.world.level.block.entity.BlockEntityType$BlockEntitySupplier",
                    "net.minecraft.block.entity.BlockEntityType$BlockEntityFactory"
            };

            for (String name : possibleNames) {
                try {
                    tempClass = Class.forName(name);
                    break;
                } catch (ClassNotFoundException ignored) {}
            }

            if (tempClass == null) {
                throw new IllegalStateException("[AsLib] Could not find BlockEntitySupplier or BlockEntityFactory class");
            }

            tempMethod = class_2591.class_2592.class.getMethod("of", tempClass, class_2248[].class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        SUPPLIER_CLASS = tempClass;
        OF_METHOD = tempMethod;
    }

    /**
     * Functional interface used to construct new {@link class_2586} instances.
     *
     * @param <T> Type of the block entity.
     */
    @FunctionalInterface
    public interface BlockEntityFactory<T extends class_2586> {
        T create(class_2338 pos, class_2680 state);
    }

    /**
     * Creates a standard {@link class_1299} builder and builds the entity type.
     *
     * @param factory  Factory creating the entity instance.
     * @param category Classification category for spawning and behavior.
     * @param width    Hitbox width.
     * @param height   Hitbox height.
     * @param key      Entity type registry path key.
     * @param <T>      Entity type class.
     * @return Constructed {@link class_1299}.
     */
    public static <T extends class_1297> class_1299<T> createEntity(
            class_1299.class_4049<T> factory,
            class_1311 category,
            float width,
            float height,
            String key
    ) {
        return class_1299.class_1300.method_5903(factory, category)
                .method_17687(width, height)
                .method_5905(key);
    }

    /**
     * Creates an {@link class_1299} with customized network tracking range and update interval settings.
     *
     * @param factory        Factory creating the entity instance.
     * @param category       Classification category.
     * @param width          Hitbox width.
     * @param height         Hitbox height.
     * @param updateInterval Tick frequency of entity position updates sent to clients.
     * @param trackingRange  Distance in chunks at which players receive entity updates.
     * @param key            Entity type registry path key.
     * @param <T>            Entity type class.
     * @return Constructed {@link class_1299}.
     */
    public static <T extends class_1297> class_1299<T> createEntity(
            class_1299.class_4049<T> factory,
            class_1311 category,
            float width,
            float height,
            int updateInterval,
            int trackingRange,
            String key
    ) {
        return class_1299.class_1300.method_5903(factory, category)
                .method_17687(width, height)
                .method_27299(trackingRange)
                .method_27300(updateInterval)
                .method_5905(key);
    }

    /**
     * Dynamically instantiates a {@link class_2591} using dynamic proxying
     * to ensure compatibility across different mapping environments (Mojang / Yarn).
     *
     * @param factory Factory creating the block entity instance.
     * @param blocks  Valid blocks bound to this block entity type.
     * @param <T>      Block entity type class.
     * @return Constructed {@link class_2591}.
     */
    @SuppressWarnings("unchecked")
    public static <T extends class_2586> class_2591<T> createBlockEntity(
            BlockEntityFactory<T> factory,
            class_2248... blocks
    ) {
        if (SUPPLIER_CLASS == null || OF_METHOD == null) {
            throw new IllegalStateException("[AsLib] RegistryHelper reflection fields are not initialized!");
        }
        try {
            Object supplierProxy = Proxy.newProxyInstance(
                    class_2591.class.getClassLoader(),
                    new Class<?>[]{SUPPLIER_CLASS},
                    (proxy, method, args) -> factory.create((class_2338) args[0], (class_2680) args[1])
            );

            class_2591.class_2592<T> builder = (class_2591.class_2592<T>) OF_METHOD.invoke(null, supplierProxy, blocks);
            return builder.method_11034(null);

        } catch (Exception e) {
            throw new RuntimeException("Failed to dynamically instantiate BlockEntityType", e);
        }
    }

    /**
     * Creates a variable-range {@link class_3414} from a string identifier.
     *
     * @param id String representation of the sound ResourceLocation.
     * @return New {@link class_3414}.
     */
    public static class_3414 createSound(String id) {
        return createSound(new class_2960(id));
    }

    /**
     * Creates a variable-range {@link class_3414}.
     *
     * @param rl ResourceLocation identifier of the sound.
     * @return New {@link class_3414}.
     */
    public static class_3414 createSound(class_2960 rl) {
        return class_3414.method_47908(rl);
    }

    /**
     * Creates a fixed-range {@link class_3414}.
     *
     * @param rl    ResourceLocation identifier of the sound.
     * @param range Maximum audible distance in blocks.
     * @return New {@link class_3414}.
     */
    public static class_3414 createFixedSound(class_2960 rl, float range) {
        return class_3414.method_47909(rl, range);
    }

    /**
     * Instantiates new default {@link class_4970.class_2251}.
     *
     * @return New block properties instance.
     */
    public static class_4970.class_2251 blockProperties() {
        return class_4970.class_2251.method_9637();
    }

    /**
     * Instantiates new default {@link class_1792.class_1793}.
     *
     * @return New item properties instance.
     */
    public static class_1792.class_1793 itemProperties() {
        return new class_1792.class_1793();
    }

    /**
     * Builds and returns a new {@link class_1761}.
     *
     * @param row          Tab row placement in the creative menu.
     * @param column       Tab column placement in the creative menu.
     * @param title        Displayed tab name.
     * @param icon         Supplier providing the tab icon stack.
     * @param displayItems Display items generator logic.
     * @return Constructed {@link class_1761}.
     */
    public static class_1761 createCreativeTab(
            class_1761.class_7915 row,
            int column,
            class_2561 title,
            Supplier<class_1799> icon,
            class_1761.class_7914 displayItems
    ) {
        return class_1761.method_47307(row, column)
                .method_47321(title)
                .method_47320(icon)
                .method_47317(displayItems)
                .method_47324();
    }
}