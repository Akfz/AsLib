package v.akfz.aslib.world.preset;

import net.minecraft.class_2960;

/**
 * Preset enum representing standard vanilla biome identifiers.
 */
public enum VanillaBiomes {
    THE_VOID("the_void"),
    PLAINS("plains"),
    DESERT("desert"),
    FOREST("forest"),
    TAIGA("taiga"),
    SWAMP("swamp"),
    JUNGLE("jungle"),
    OCEAN("ocean"),
    DEEP_OCEAN("deep_ocean"),
    DEEP_DARK("deep_dark"),
    MEADOW("meadow"),
    NETHER_WASTES("nether_wastes"),
    CRIMSON_FOREST("crimson_forest"),
    WARPED_FOREST("warped_forest"),
    SOUL_SAND_VALLEY("soul_sand_valley"),
    BASALT_DELTAS("basalt_deltas"),
    THE_END("the_end"),
    END_MIDLANDS("end_midlands"),
    END_BARRENS("end_barrens");

    private final class_2960 location;

    VanillaBiomes(String path) {
        this.location = new class_2960("minecraft", path);
    }

    public class_2960 location() {
        return location;
    }
}