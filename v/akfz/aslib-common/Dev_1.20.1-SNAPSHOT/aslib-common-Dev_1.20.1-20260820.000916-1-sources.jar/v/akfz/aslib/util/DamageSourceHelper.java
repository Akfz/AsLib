package v.akfz.aslib.util;

import org.jetbrains.annotations.Nullable;
import v.akfz.aslib.datagen.damagetype.DamageTypeData;
import v.akfz.aslib.resourcepack.dynamic.DynamicDataPack;

import java.util.Optional;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_8110;
import net.minecraft.class_8111;

/**
 * REALLY simplifies things for creation new damage sources, to 1-2 lines code
 */
public final class DamageSourceHelper {

    private DamageSourceHelper() {}

    public static class_5321<class_8110> createKey(String id) {
        return createKey(new class_2960(id));
    }

    public static class_5321<class_8110> createKey(class_2960 location) {
        return createKey(location, new DamageTypeData(location));
    }

    public static class_5321<class_8110> createKey(String id, DamageTypeData data) {
        return createKey(new class_2960(id), data);
    }

    public static class_5321<class_8110> createKey(String id, DamageTypeData data, String subProjectName) {
        return createKey(new class_2960(id), data);
    }

    public static class_5321<class_8110> createKey(class_2960 location, DamageTypeData data) {
        class_2960 jsonPath = new class_2960(location.method_12836(), "damage_type/" + location.method_12832() + ".json");

        DynamicDataPack.addData(jsonPath, data.serialize());

        return class_5321.method_29179(class_7924.field_42534, location);
    }

    public static class_1282 create(class_1937 level, class_5321<class_8110> key) {
        return create(level, key, null, null);
    }

    public static class_1282 create(class_1937 level, class_5321<class_8110> key, @Nullable class_1297 causingEntity) {
        return create(level, key, causingEntity, causingEntity);
    }

    public static class_1282 create(class_1937 level, class_5321<class_8110> key, @Nullable class_1297 directEntity, @Nullable class_1297 causingEntity) {
        var registry = level.method_30349().method_30530(class_7924.field_42534);
        Optional<class_6880.class_6883<class_8110>> holderOpt = registry.method_40264(key);

        if (holderOpt.isEmpty()) {
            System.err.println("[ASLib] WARNING: DamageType '" + key.method_29177() + "' is not loaded in world registry! Using GENERIC fallback.");
            class_6880<class_8110> fallback = registry.method_40290(class_8111.field_42348);
            return new class_1282(fallback, directEntity, causingEntity);
        }

        return new class_1282(holderOpt.get(), directEntity, causingEntity);
    }

    public static class_1282 create(class_1937 level, class_5321<class_8110> key, class_243 pos) {
        var registry = level.method_30349().method_30530(class_7924.field_42534);
        Optional<class_6880.class_6883<class_8110>> holderOpt = registry.method_40264(key);

        if (holderOpt.isEmpty()) {
            System.err.println("[ASLib] WARNING: DamageType '" + key.method_29177() + "' is not loaded in world registry! Using GENERIC fallback.");
            class_6880<class_8110> fallback = registry.method_40290(class_8111.field_42348);
            return new class_1282(fallback, pos);
        }

        return new class_1282(holderOpt.get(), pos);
    }
}