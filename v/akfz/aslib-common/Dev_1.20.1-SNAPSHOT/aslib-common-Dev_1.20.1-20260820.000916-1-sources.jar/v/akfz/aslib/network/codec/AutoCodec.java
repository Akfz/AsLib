package v.akfz.aslib.network.codec;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.RecordComponent;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class AutoCodec {

    private static final Map<Class<?>, TypeCodec<?>> TYPE_CODECS = new ConcurrentHashMap<>();
    private static final Map<Class<?>, List<Field>> FIELD_CACHE = new ConcurrentHashMap<>();

    static {
        registerType(int.class, Integer.class, class_2540::method_10804, class_2540::method_10816);
        registerType(float.class, Float.class, class_2540::writeFloat, class_2540::readFloat);
        registerType(double.class, Double.class, class_2540::writeDouble, class_2540::readDouble);
        registerType(boolean.class, Boolean.class, class_2540::writeBoolean, class_2540::readBoolean);
        registerType(long.class, Long.class, class_2540::writeLong, class_2540::readLong);

        registerType(String.class, new TypeCodec<>() {
            @Override
            public void encode(class_2540 buf, String value) {
                buf.method_10814(value);
            }

            @Override
            public String decode(class_2540 buf) {
                return buf.method_19772();
            }
        });

        registerType(class_2960.class, new TypeCodec<>() {
            @Override
            public void encode(class_2540 buf, class_2960 value) {
                buf.method_10812(value);
            }

            @Override
            public class_2960 decode(class_2540 buf) {
                return buf.method_10810();
            }
        });

        registerType(UUID.class, new TypeCodec<>() {
            @Override
            public void encode(class_2540 buf, UUID value) {
                buf.method_10797(value);
            }

            @Override
            public UUID decode(class_2540 buf) {
                return buf.method_10790();
            }
        });

        registerType(class_243.class, new TypeCodec<>() {
            @Override
            public void encode(class_2540 buf, class_243 value) {
                buf.writeDouble(value.field_1352);
                buf.writeDouble(value.field_1351);
                buf.writeDouble(value.field_1350);
            }

            @Override
            public class_243 decode(class_2540 buf) {
                return new class_243(buf.readDouble(), buf.readDouble(), buf.readDouble());
            }
        });
    }

    public static <T> void registerType(Class<T> clazz, TypeCodec<T> codec) {
        TYPE_CODECS.put(clazz, codec);
    }

    public static <T> void registerType(Class<T> primClass, Class<T> wrapClass, TypeEncoder<T> encoder, TypeDecoder<T> decoder) {
        TypeCodec<T> codec = new TypeCodec<>() {
            @Override public void encode(class_2540 buf, T value) { encoder.encode(buf, value); }
            @Override public T decode(class_2540 buf) { return decoder.decode(buf); }
        };
        if (primClass != null) TYPE_CODECS.put(primClass, codec);
        if (wrapClass != null) TYPE_CODECS.put(wrapClass, codec);
    }

    @SuppressWarnings("unchecked")
    public static void encode(class_2540 buf, Object obj) {
        if (obj == null) {
            buf.writeBoolean(false);
            return;
        }
        buf.writeBoolean(true);

        Class<?> clazz = obj.getClass();
        TypeCodec<Object> codec = (TypeCodec<Object>) TYPE_CODECS.get(clazz);

        if (codec != null) {
            codec.encode(buf, obj);
            return;
        }

        try {
            if (clazz.isRecord()) {
                for (RecordComponent component : clazz.getRecordComponents()) {
                    Object val = component.getAccessor().invoke(obj);
                    encode(buf, val);
                }
            } else {
                List<Field> fields = getFields(clazz);
                for (Field field : fields) {
                    encode(buf, field.get(obj));
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to encode class: " + clazz.getName(), e);
        }
    }

    @SuppressWarnings("unchecked")
    public static <T> T decode(class_2540 buf, Class<T> clazz) {
        if (!buf.readBoolean()) {
            return null;
        }

        TypeCodec<T> codec = (TypeCodec<T>) TYPE_CODECS.get(clazz);

        if (codec != null) {
            return codec.decode(buf);
        }

        try {
            if (clazz.isRecord()) {
                RecordComponent[] components = clazz.getRecordComponents();
                Class<?>[] paramTypes = new Class<?>[components.length];
                Object[] args = new Object[components.length];

                for (int i = 0; i < components.length; i++) {
                    paramTypes[i] = components[i].getType();
                    args[i] = decode(buf, paramTypes[i]);
                }

                Constructor<T> canonicalConstructor = clazz.getDeclaredConstructor(paramTypes);
                canonicalConstructor.setAccessible(true);
                return canonicalConstructor.newInstance(args);
            } else {
                T instance = clazz.getDeclaredConstructor().newInstance();
                List<Field> fields = getFields(clazz);

                for (Field field : fields) {
                    Object fieldValue = decode(buf, field.getType());
                    field.set(instance, fieldValue);
                }
                return instance;
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to decode class: " + clazz.getName(), e);
        }
    }

    private static List<Field> getFields(Class<?> clazz) {
        return FIELD_CACHE.computeIfAbsent(clazz, c -> {
            List<Field> list = new ArrayList<>();
            Class<?> current = c;
            while (current != null && current != Object.class) {
                for (Field f : current.getDeclaredFields()) {
                    if (!Modifier.isStatic(f.getModifiers()) && !Modifier.isTransient(f.getModifiers())) {
                        f.setAccessible(true);
                        list.add(f);
                    }
                }
                current = current.getSuperclass();
            }
            return list;
        });
    }

    @FunctionalInterface public interface TypeEncoder<T> { void encode(class_2540 buf, T val); }
    @FunctionalInterface public interface TypeDecoder<T> { T decode(class_2540 buf); }
}