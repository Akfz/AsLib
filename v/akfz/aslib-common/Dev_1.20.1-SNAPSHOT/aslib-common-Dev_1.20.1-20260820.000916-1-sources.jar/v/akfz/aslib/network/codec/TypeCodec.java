package v.akfz.aslib.network.codec;

import net.minecraft.class_2540;

public interface TypeCodec<T> {
    void encode(class_2540 buf, T value);
    T decode(class_2540 buf);
}