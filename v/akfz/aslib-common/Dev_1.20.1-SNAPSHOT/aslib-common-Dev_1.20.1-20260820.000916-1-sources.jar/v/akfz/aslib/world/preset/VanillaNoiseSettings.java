package v.akfz.aslib.world.preset;

import net.minecraft.class_2960;

/**
 * Preset enum representing standard vanilla noise generator settings identifiers.
 */
public enum VanillaNoiseSettings {
    OVERWORLD("overworld"),
    LARGE_BIOMES("large_biomes"),
    AMPLIFIED("amplified"),
    NETHER("nether"),
    END("end"),
    CAVES("caves"),
    FLOATING_ISLANDS("floating_islands");

    private final class_2960 location;

    VanillaNoiseSettings(String path) {
        this.location = new class_2960("minecraft", path);
    }

    public class_2960 location() {
        return location;
    }
}