package v.akfz.aslib.datagen.block.blockstate;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.class_2960;

/**
 * Generates simplest blockstate, without rotations etc., only static render model
 */
public class SimpleBlockStateVariant implements BlockStateVariant {
    private final String key;
    private final class_2960 modelId;

    public SimpleBlockStateVariant(class_2960 modelId) {
        this("", modelId);
    }

    public SimpleBlockStateVariant(String key, class_2960 modelId) {
        this.key = key;
        this.modelId = modelId;
    }

    @Override
    public String getKey() {
        return this.key;
    }

    @Override
    public JsonElement serialize() {
        JsonObject json = new JsonObject();
        json.addProperty("model", modelId.toString());
        return json;
    }
}