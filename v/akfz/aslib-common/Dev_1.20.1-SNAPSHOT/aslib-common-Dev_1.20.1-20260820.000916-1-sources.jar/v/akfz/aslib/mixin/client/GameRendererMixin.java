package v.akfz.aslib.mixin.client;

import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import v.akfz.aslib.render.camera.CameraExtender;

@Mixin(class_757.class)
public class GameRendererMixin {
    @Final @Shadow
    private class_4184 mainCamera;

    @Inject(
            method = "renderLevel",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/vertex/PoseStack;mulPose(Lorg/joml/Quaternionf;)V",
                    shift = At.Shift.AFTER,
                    ordinal = 3
            )
    )
    public void renderLevelMixin(float partialTicks, long finishTimeNano, class_4587 poseStack, CallbackInfo ci) {
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(-(float) ((CameraExtender) mainCamera).getRot().field_1350));
    }
}