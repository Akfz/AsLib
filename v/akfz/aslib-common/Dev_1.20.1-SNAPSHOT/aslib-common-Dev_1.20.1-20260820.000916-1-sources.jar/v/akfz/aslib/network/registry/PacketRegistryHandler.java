package v.akfz.aslib.network.registry;

import net.minecraft.class_3222;
import v.akfz.aslib.network.api.Packet;

public class PacketRegistryHandler {
    private final PacketRegistry registry;

    public PacketRegistryHandler(PacketRegistry registry) {
        this.registry = registry;
    }

    @SuppressWarnings("unchecked")
    public void handle(Packet packet) {
        PacketEntry<?> entry = this.registry.get(packet.getClass());
        if (entry == null) {
            throw new IllegalStateException("Packet not registered: " + packet.getClass());
        } else {
            ((PacketEntry<Packet>) entry).handler().handle(packet);
        }
    }

    @SuppressWarnings("unchecked")
    public void handle(Packet packet, class_3222 sender) {
        PacketEntry<?> entry = this.registry.get(packet.getClass());
        if (entry == null) {
            throw new IllegalStateException("Packet not registered: " + packet.getClass());
        } else {
            ((PacketEntry<Packet>) entry).handler().handle(packet, sender);
        }
    }
}