package v.akfz.aslib.command;

import com.mojang.brigadier.arguments.*;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2232;
import net.minecraft.class_2300;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Helper for commands arguments
 */
public abstract class CommandHelper {

    /**
     * Creates a literal argument (subcommand name)
     */
    protected LiteralArgumentBuilder<class_2168> literal(String name) {
        return class_2170.method_9247(name);
    }

    /**
     * Creates a single-word string argument
     */
    protected RequiredArgumentBuilder<class_2168, String> string(String name) {
        return class_2170.method_9244(name, StringArgumentType.string());
    }

    /**
     * Creates a greedy string argument (reads everything till the end)
     */
    protected RequiredArgumentBuilder<class_2168, String> greedyString(String name) {
        return class_2170.method_9244(name, StringArgumentType.greedyString());
    }

    /**
     * Creates an integer argument
     */
    protected RequiredArgumentBuilder<class_2168, Integer> integer(String name) {
        return class_2170.method_9244(name, IntegerArgumentType.integer());
    }

    /**
     * Creates a decimal (double) argument
     */
    protected RequiredArgumentBuilder<class_2168, Double> decimal(String name) {
        return class_2170.method_9244(name, DoubleArgumentType.doubleArg());
    }

    /**
     * Creates a boolean argument
     */
    protected RequiredArgumentBuilder<class_2168, Boolean> bool(String name) {
        return class_2170.method_9244(name, BoolArgumentType.bool());
    }

    /**
     * Creates a single player selector argument
     */
    protected RequiredArgumentBuilder<class_2168, class_2300> player(String name) {
        return class_2170.method_9244(name, class_2186.method_9305());
    }

    /**
     * Creates a multiple players selector argument
     */
    protected RequiredArgumentBuilder<class_2168, class_2300> players(String name) {
        return class_2170.method_9244(name, class_2186.method_9308());
    }

    /**
     * Creates a single entity selector argument
     */
    protected RequiredArgumentBuilder<class_2168, class_2300> entity(String name) {
        return class_2170.method_9244(name, class_2186.method_9309());
    }

    /**
     * Creates a multiple entities selector argument
     */
    protected RequiredArgumentBuilder<class_2168, class_2300> entities(String name) {
        return class_2170.method_9244(name, class_2186.method_9306());
    }

    /**
     * Creates a ResourceLocation (identifier) argument
     */
    protected RequiredArgumentBuilder<class_2168, class_2960> identifier(String name) {
        return class_2170.method_9244(name, class_2232.method_9441());
    }

    /**
     * Checks if the command source has specified permission level
     */
    protected Predicate<class_2168> hasLevel(int level) {
        return src -> src.method_9259(level);
    }

    /**
     * Checks if the command source is a player
     */
    protected Predicate<class_2168> isPlayer() {
        return src -> src.method_9228() instanceof class_3222;
    }

    /**
     * Checks if the command source is a player AND has permission level
     */
    protected Predicate<class_2168> hasLevelAndIsPlayer(int level) {
        return isPlayer().and(hasLevel(level));
    }

    /**
     * Gets string argument value from context
     */
    protected String getString(CommandContext<class_2168> ctx, String name) {
        return StringArgumentType.getString(ctx, name);
    }

    /**
     * Gets integer argument value from context
     */
    protected int getInt(CommandContext<class_2168> ctx, String name) {
        return IntegerArgumentType.getInteger(ctx, name);
    }

    /**
     * Gets double argument value from context
     */
    protected double getDouble(CommandContext<class_2168> ctx, String name) {
        return DoubleArgumentType.getDouble(ctx, name);
    }

    /**
     * Gets boolean argument value from context
     */
    protected boolean getBool(CommandContext<class_2168> ctx, String name) {
        return BoolArgumentType.getBool(ctx, name);
    }

    /**
     * Gets ResourceLocation argument value from context
     */
    protected class_2960 getID(CommandContext<class_2168> ctx, String name) {
        return class_2232.method_9443(ctx, name);
    }

    /**
     * Sets permission level requirement for literal builder
     */
    protected LiteralArgumentBuilder<class_2168> requires(LiteralArgumentBuilder<class_2168> builder, int level) {
        return builder.requires(src -> src.method_9259(level));
    }

    /**
     * Sets action to execute for literal builder
     */
    protected LiteralArgumentBuilder<class_2168> executes(LiteralArgumentBuilder<class_2168> builder, Consumer<CommandContext<class_2168>> action) {
        return builder.executes(ctx -> {
            action.accept(ctx);
            return 1;
        });
    }

    /**
     * Sets action to execute for argument builder
     */
    protected <T> RequiredArgumentBuilder<class_2168, T> executes(RequiredArgumentBuilder<class_2168, T> builder, Consumer<CommandContext<class_2168>> action) {
        return builder.executes(ctx -> {
            action.accept(ctx);
            return 1;
        });
    }
}