package v.akfz.aslib.network.bundle;

import v.akfz.aslib.network.annotation.NetworkPacket;
import v.akfz.aslib.network.api.Packet;
import v.akfz.aslib.network.api.PacketDecoder;
import v.akfz.aslib.network.api.PacketEncoder;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

@NetworkPacket("aslib:bundle_header")
public final class BundleHeaderPacket implements Packet {
    private final long bundleId;
    private final List<Entry> entries;

    public BundleHeaderPacket(long bundleId, List<Entry> entries) {
        this.bundleId = bundleId;
        this.entries = entries;
    }

    public long getBundleId() { return bundleId; }
    public List<Entry> getEntries() { return entries; }

    public static void encode(BundleHeaderPacket packet, class_2540 buf) {
        buf.writeLong(packet.bundleId);
        buf.method_10804(packet.entries.size());
        for (Entry entry : packet.entries) {
            buf.method_10812(entry.id());
            buf.method_10804(entry.length());
        }
    }

    public static BundleHeaderPacket decode(class_2540 buf) {
        long bundleId = buf.readLong();
        int size = buf.method_10816();
        List<Entry> entries = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            class_2960 id = buf.method_10810();
            int length = buf.method_10816();
            entries.add(new Entry(id, length));
        }
        return new BundleHeaderPacket(bundleId, entries);
    }

    @Override
    public PacketEncoder<BundleHeaderPacket> encoder() { return BundleHeaderPacket::encode; }
    @Override
    public PacketDecoder<BundleHeaderPacket> decoder() { return BundleHeaderPacket::decode; }

    public record Entry(class_2960 id, int length) {}
}