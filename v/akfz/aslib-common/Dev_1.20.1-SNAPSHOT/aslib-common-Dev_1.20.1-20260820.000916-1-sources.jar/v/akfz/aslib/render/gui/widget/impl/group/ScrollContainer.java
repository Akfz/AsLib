package v.akfz.aslib.render.gui.widget.impl.group;

import v.akfz.aslib.render.gui.widget.api.AbstractGroupWidget;
import v.akfz.aslib.render.color.ColorUtils;
import v.akfz.aslib.render.gui.widget.api.AbstractWidget;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import org.lwjgl.glfw.GLFW;

public class ScrollContainer extends AbstractGroupWidget {
    private int contentWidth;
    private int contentHeight;
    private int scrollOffsetX = 0;
    private int scrollOffsetY = 0;

    private boolean draggingScrollbarY = false;
    private boolean draggingScrollbarX = false;

    private double lastMouseX = 0;
    private double lastMouseY = 0;
    private boolean wasMiddlePressed = false;

    protected int scrollbarColor = ColorUtils.rgbToArgb(255, 255, 255, 255);
    protected int scrollbarBgColor = ColorUtils.rgbToArgb(255, 80, 80, 80);

    public ScrollContainer(int x, int y, int width, int height) {
        super(x, y, width, height);
        this.contentWidth = width;
        this.contentHeight = height;
    }

    @Override
    protected void doRender(class_332 graphics, int mouseX, int mouseY, float delta) {
        long windowHandle = class_310.method_1551().method_22683().method_4490();
        boolean isMiddlePressed = GLFW.glfwGetMouseButton(windowHandle, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;

        if (isMiddlePressed) {
            if (!wasMiddlePressed && method_25405(mouseX, mouseY) && visible) {
                wasMiddlePressed = true;
                lastMouseX = mouseX;
                lastMouseY = mouseY;
            } else if (wasMiddlePressed) {
                double deltaX = mouseX - lastMouseX;
                double deltaY = mouseY - lastMouseY;

                if (contentWidth > width) {
                    setScrollOffsetX(scrollOffsetX - (int) deltaX);
                }
                if (contentHeight > height) {
                    setScrollOffsetY(scrollOffsetY - (int) deltaY);
                }

                lastMouseX = mouseX;
                lastMouseY = mouseY;
            }
        } else {
            wasMiddlePressed = false;
        }

        graphics.method_44379(x, y, x + width, y + height);
        graphics.method_25294(x, y, x + width, y + height, ColorUtils.rgbToArgb(255, 50, 50, 50));

        class_4587 poseStack = graphics.method_51448();
        poseStack.method_22903();
        poseStack.method_46416(x - scrollOffsetX, y - scrollOffsetY, 0);

        int correctedMouseX = (int) (mouseX - (x - scrollOffsetX));
        int correctedMouseY = (int) (mouseY - (y - scrollOffsetY));

        for (AbstractWidget child : children) {
            if (child.isVisible() &&
                    child.getX() + child.getWidth() > scrollOffsetX && child.getX() < scrollOffsetX + width &&
                    child.getY() + child.getHeight() > scrollOffsetY && child.getY() < scrollOffsetY + height) {
                child.method_25394(graphics, correctedMouseX, correctedMouseY, delta);
            }
        }

        poseStack.method_22909();
        graphics.method_44380();

        if (contentHeight > height) renderScrollbarY(graphics, mouseX, mouseY);
        if (contentWidth > width) renderScrollbarX(graphics, mouseX, mouseY);
    }

    private void renderScrollbarY(class_332 graphics, int mouseX, int mouseY) {
        int barHeight = Math.max(10, (int) ((float) height / contentHeight * height));
        int maxScrollY = contentHeight - height;
        int barY = y + (int) ((float) scrollOffsetY / maxScrollY * (height - barHeight));
        int barX = x + width - 6;

        graphics.method_25294(barX, y, barX + 4, y + height, scrollbarBgColor);

        boolean hovered = mouseX >= barX && mouseX < barX + 4 && mouseY >= barY && mouseY < barY + barHeight;
        int color = (draggingScrollbarY || hovered) ? ColorUtils.brighten(scrollbarColor, 30) : scrollbarColor;
        graphics.method_25294(barX, barY, barX + 4, barY + barHeight, color);
    }

    private void renderScrollbarX(class_332 graphics, int mouseX, int mouseY) {
        int barWidth = Math.max(10, (int) ((float) width / contentWidth * width));
        int maxScrollX = contentWidth - width;
        int barX = x + (int) ((float) scrollOffsetX / maxScrollX * (width - barWidth));
        int barY = y + height - 6;

        graphics.method_25294(x, barY, x + width, barY + 4, scrollbarBgColor);

        boolean hovered = mouseX >= barX && mouseX < barX + barWidth && mouseY >= barY && mouseY < barY + 4;
        int color = (draggingScrollbarX || hovered) ? ColorUtils.brighten(scrollbarColor, 30) : scrollbarColor;
        graphics.method_25294(barX, barY, barX + barWidth, barY + 4, color);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!visible || !method_25405(mouseX, mouseY)) return false;

        if (button == 0) {
            if (contentHeight > height && mouseX >= x + width - 6 && mouseX < x + width - 2) {
                draggingScrollbarY = true;
                return true;
            }

            if (contentWidth > width && mouseY >= y + height - 6 && mouseY < y + height - 2) {
                draggingScrollbarX = true;
                return true;
            }
        }

        double correctedMouseX = mouseX - (x - scrollOffsetX);
        double correctedMouseY = mouseY - (y - scrollOffsetY);

        for (AbstractWidget child : children) {
            if (child.isVisible() && child.method_25405(correctedMouseX, correctedMouseY)) {
                if (child.method_25402(correctedMouseX, correctedMouseY, button)) {
                    method_25395(child);
                    this.method_25398(true);
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        draggingScrollbarY = false;
        draggingScrollbarX = false;
        this.method_25398(false);

        double correctedMouseX = mouseX - (x - scrollOffsetX);
        double correctedMouseY = mouseY - (y - scrollOffsetY);

        if (method_25399() != null) {
            return method_25399().method_25406(correctedMouseX, correctedMouseY, button);
        }
        return super.method_25406(correctedMouseX, correctedMouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingScrollbarY) {
            int barHeight = Math.max(10, (int) ((float) height / contentHeight * height));
            int scrollAreaY = height - barHeight;
            if (scrollAreaY > 0) {
                float scrollBy = (float) deltaY / scrollAreaY * (contentHeight - height);
                setScrollOffsetY(scrollOffsetY + (int) scrollBy);
            }
            return true;
        }

        if (draggingScrollbarX) {
            int barWidth = Math.max(10, (int) ((float) width / contentWidth * width));
            int scrollAreaX = width - barWidth;
            if (scrollAreaX > 0) {
                float scrollBy = (float) deltaX / scrollAreaX * (contentWidth - width);
                setScrollOffsetX(scrollOffsetX + (int) scrollBy);
            }
            return true;
        }

        double correctedMouseX = mouseX - (x - scrollOffsetX);
        double correctedMouseY = mouseY - (y - scrollOffsetY);

        if (method_25399() != null) {
            return method_25399().method_25403(correctedMouseX, correctedMouseY, button, deltaX, deltaY);
        }
        return super.method_25403(correctedMouseX, correctedMouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        if (!visible || !method_25405(mouseX, mouseY)) return false;

        double correctedMouseX = mouseX - (x - scrollOffsetX);
        double correctedMouseY = mouseY - (y - scrollOffsetY);

        for (AbstractWidget child : children) {
            if (child.isVisible() && child.method_25405(correctedMouseX, correctedMouseY)) {
                if (child.method_25401(correctedMouseX, correctedMouseY, amount)) return true;
            }
        }

        if (GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS) {
            if (contentWidth > width) {
                setScrollOffsetX(scrollOffsetX - (int) (amount * 14));
                return true;
            }
        } else {
            if (contentHeight > height) {
                setScrollOffsetY(scrollOffsetY - (int) (amount * 14));
                return true;
            }
        }
        return false;
    }

    public void scrollTo(int offsetX, int offsetY) {
        setScrollOffsetX(offsetX);
        setScrollOffsetY(offsetY);
    }

    public void scrollToWidget(AbstractWidget widget) {
        if (children.contains(widget)) {
            scrollTo(widget.getX() - x, widget.getY() - y);
        }
    }

    public int getContentWidth() { return contentWidth; }
    public void setContentWidth(int contentWidth) { this.contentWidth = contentWidth; }
    public int getContentHeight() { return contentHeight; }
    public void setContentHeight(int contentHeight) { this.contentHeight = contentHeight; }
    public int getScrollOffsetX() { return scrollOffsetX; }
    public void setScrollOffsetX(int scrollOffsetX) { this.scrollOffsetX = Math.max(0, Math.min(contentWidth - width, scrollOffsetX)); }
    public int getScrollOffsetY() { return scrollOffsetY; }
    public void setScrollOffsetY(int scrollOffsetY) { this.scrollOffsetY = Math.max(0, Math.min(contentHeight - height, scrollOffsetY)); }
    public int getScrollbarColor() { return scrollbarColor; }
    public void setScrollbarColor(int scrollbarColor) { this.scrollbarColor = scrollbarColor; }
    public int getScrollbarBgColor() { return scrollbarBgColor; }
    public void setScrollbarBgColor(int scrollbarBgColor) { this.scrollbarBgColor = scrollbarBgColor; }
}