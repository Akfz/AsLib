package v.akfz.aslib.datagen.api;

import com.google.gson.JsonElement;
import net.minecraft.class_2960;

/**
 * "Class for generating a file and a path"
 */
public abstract class DataSerializable implements Serializable<JsonElement> {
    private final class_2960 path;

    public DataSerializable(class_2960 path) {
        this.path = path;
    }

    @Override
    public class_2960 getRLPath() {
        return this.path;
    }

    @Override
    public abstract JsonElement serialize();
}
