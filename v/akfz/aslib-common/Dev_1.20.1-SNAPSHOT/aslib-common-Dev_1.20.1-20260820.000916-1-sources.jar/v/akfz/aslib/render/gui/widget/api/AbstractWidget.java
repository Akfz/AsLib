package v.akfz.aslib.render.gui.widget.api;

import v.akfz.aslib.render.color.ColorUtils;
import v.akfz.aslib.render.gui.widget.api.render.RenderExtras;
import v.akfz.aslib.render.gui.widget.api.render.RenderPart;
import v.akfz.aslib.render.gui.widget.api.tooltip.AbstractToolTip;
import v.akfz.aslib.render.gui.widget.impl.tooltip.DefaultToolTip;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;
import net.minecraft.class_6382;

/**
 * My variations and vision of gui-widgets
 */
public abstract class AbstractWidget implements class_4068, class_364, class_6379 {
    protected int x, y, width, height;
    protected boolean visible = true;
    protected boolean hovered = false;

    protected RenderPart mainRenderer;
    protected boolean focused = false;
    protected AbstractToolTip toolTip;

    public AbstractWidget(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public AbstractWidget setTextTooltip(List<String> textTooltip) {
        if (toolTip == null) {
            toolTip = new DefaultToolTip(4,4,4,4);
        }
        toolTip.setText(textTooltip);
        return this;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void setScale(int w, int h) {
        this.width = w;
        this.height = h;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public boolean isVisible() {
        return this.visible;
    }

    public boolean isHovered() {
        return this.hovered;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        if (!visible) return;

        hovered = mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
        doRender(graphics, mouseX, mouseY, delta);
        if (toolTip != null && hovered) {
            toolTip.method_25394(graphics, mouseX, mouseY, delta);
        }
    }

    protected void doRender(class_332 graphics, int mouseX, int mouseY, float delta) {
        if (mainRenderer == null) {
            mainRenderer = new nullRenderer();
        }

        mainRenderer.render(graphics, mouseX, mouseY, delta, x, y, width, height, new RenderExtras());
    }

    @Override
    public void method_25365(boolean focused) {
        this.focused = focused;
    }

    @Override
    public boolean method_25370() {
        return focused;
    }

    @Override
    public @NotNull class_6380 method_37018() {
        return class_6380.field_33784;
    }

    @Override
    public void method_37020(class_6382 narrationElementOutput) {}

    private static class nullRenderer implements RenderPart {

        @Override
        public void render(class_332 context, int mouseX, int mouseY, float delta, int x, int y, int width,
                           int height, RenderExtras extras) {
            String text = "рендер не выбран!";
            context.method_25294(x, y, x + width, y + height, ColorUtils.rgbToArgb(90));
            context.method_49601(x, y, width, height, ColorUtils.rgbToArgb(115));

            int textX = x + (width - class_310.method_1551().field_1772.method_1727(text)) / 2;
            int textY = y + (height - 8) / 2;
            context.method_51433(class_310.method_1551().field_1772, text, textX, textY, ColorUtils.white(),
                    true);
        }
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return this.hovered;
    }
}
