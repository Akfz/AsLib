package v.akfz.aslib.resourcepack.dynamic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import v.akfz.aslib.resourcepack.AddResourcePack;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3270;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_5352;
import net.minecraft.class_7367;

/**
 * In-memory {@link class_3262} implementation for dynamically registering virtual data pack JSON files at runtime.
 */
public class DynamicDataPack implements class_3262 {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final DynamicDataPack INSTANCE = new DynamicDataPack();

    private static final Set<class_3283> REGISTERED_REPOS = ConcurrentHashMap.newKeySet();

    private final Map<class_2960, byte[]> virtualFiles = new ConcurrentHashMap<>();
    private final Set<String> namespaces = ConcurrentHashMap.newKeySet();

    private DynamicDataPack() {}

    public static DynamicDataPack getInstance() {
        return INSTANCE;
    }

    /**
     * Adds virtual JSON data to the dynamic data pack.
     */
    public static void addData(class_2960 location, JsonElement json) {
        byte[] bytes = GSON.toJson(json).getBytes(StandardCharsets.UTF_8);
        INSTANCE.virtualFiles.put(location, bytes);
        INSTANCE.namespaces.add(location.method_12836());
    }

    /**
     * Registers the dynamic data pack into the provided repository.
     */
    public static void registerToRepository(class_3283 repository) {
        if (REGISTERED_REPOS.add(repository)) {
            AddResourcePack.addServerData(
                    repository,
                    INSTANCE,
                    class_2561.method_43470("ASLib Built-in Dynamic DataPack"),
                    "aslib_dynamic_datapack",
                    class_2561.method_43470("Dynamic DataPack"),
                    true,
                    class_3288.class_3289.field_14280,
                    true,
                    class_5352.field_25348
            );
        }
    }

    @Override
    public @Nullable class_7367<InputStream> method_14410(String... strings) {
        return null;
    }

    @Override
    public @Nullable class_7367<InputStream> method_14405(class_3264 packType, class_2960 location) {
        if (packType != class_3264.field_14190) return null;

        byte[] data = virtualFiles.get(location);
        if (data != null) {
            return () -> new ByteArrayInputStream(data);
        }

        return null;
    }

    @Override
    public void method_14408(class_3264 packType, String namespace, String prefix, class_7664 resourceOutput) {
        if (packType != class_3264.field_14190) return;

        for (Map.Entry<class_2960, byte[]> entry : virtualFiles.entrySet()) {
            class_2960 loc = entry.getKey();
            if (loc.method_12836().equals(namespace) && loc.method_12832().startsWith(prefix)) {
                byte[] bytes = entry.getValue();
                resourceOutput.accept(loc, () -> new ByteArrayInputStream(bytes));
            }
        }
    }

    @Override
    public @NotNull Set<String> method_14406(class_3264 packType) {
        return packType == class_3264.field_14190 ? namespaces : Set.of();
    }

    @Override
    public @Nullable <T> T method_14407(class_3270<T> metadataSectionSerializer) {
        return null;
    }

    @Override
    public String method_14409() {
        return "aslib_dynamic_datapack";
    }

    @Override
    public void close() {
        virtualFiles.clear();
    }
}