package v.akfz.aslib.network.api;

import net.minecraft.class_2540;

@FunctionalInterface
public interface PacketDecoder<T extends Packet> {
    T decode(class_2540 buf);
}
