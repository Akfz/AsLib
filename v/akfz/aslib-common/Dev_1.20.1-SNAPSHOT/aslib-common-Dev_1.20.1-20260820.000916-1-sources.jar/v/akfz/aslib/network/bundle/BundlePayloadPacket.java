package v.akfz.aslib.network.bundle;

import net.minecraft.class_2540;
import v.akfz.aslib.network.annotation.NetworkPacket;
import v.akfz.aslib.network.api.Packet;
import v.akfz.aslib.network.api.PacketDecoder;
import v.akfz.aslib.network.api.PacketEncoder;

@NetworkPacket("aslib:bundle_payload")
public final class BundlePayloadPacket implements Packet {
    private final long bundleId;
    private final byte[] data;

    public BundlePayloadPacket(long bundleId, byte[] data) {
        this.bundleId = bundleId;
        this.data = data;
    }

    public long getBundleId() { return bundleId; }
    public byte[] getData() { return data; }

    public static void encode(BundlePayloadPacket packet, class_2540 buf) {
        buf.writeLong(packet.bundleId);
        buf.method_10813(packet.data);
    }

    public static BundlePayloadPacket decode(class_2540 buf) {
        long bundleId = buf.readLong();
        byte[] data = buf.method_10795();
        return new BundlePayloadPacket(bundleId, data);
    }

    @Override
    public PacketEncoder<BundlePayloadPacket> encoder() { return BundlePayloadPacket::encode; }
    @Override
    public PacketDecoder<BundlePayloadPacket> decoder() { return BundlePayloadPacket::decode; }
}