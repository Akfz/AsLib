package v.akfz.aslib.resourcepack;

import net.minecraft.class_3285;

public interface ResourcePackExpander {
    void addProvider(class_3285 provider);
    void removeProvider(class_3285 provider);
}

