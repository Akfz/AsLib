package v.akfz.aslib.mixin;

import v.akfz.aslib.resourcepack.ResourcePackExpander;
import v.akfz.aslib.resourcepack.configpack.ConfigPack;
import v.akfz.aslib.resourcepack.dynamic.DynamicDataPack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;
import net.minecraft.class_3283;
import net.minecraft.class_3285;
import net.minecraft.class_3288;

@Mixin(class_3283.class)
public class ResourcePackManagerMixin implements ResourcePackExpander {
    @Unique private final Set<class_3285> aslib$additionalProviders = new HashSet<>();

    @Override
    public void addProvider(class_3285 provider) {
        this.aslib$additionalProviders.add(provider);
    }

    @Override
    public void removeProvider(class_3285 provider) {
        this.aslib$additionalProviders.remove(provider);
    }

    @Inject(method = "discoverAvailable", at = @At("HEAD"))
    private void aslib$registerDynamicPacks(CallbackInfoReturnable<Map<String, class_3288>> cir) {
        class_3283 repo = (class_3283) (Object) this;
        DynamicDataPack.registerToRepository(repo);
        ConfigPack.registerToRepository(repo);
    }

    @Inject(method = "discoverAvailable", at = @At("RETURN"), cancellable = true)
    private void aslib$injectAdditionalProviders(CallbackInfoReturnable<Map<String, class_3288>> cir) {
        Map<String, class_3288> originalMap = cir.getReturnValue();
        Map<String, class_3288> extendedMap = new TreeMap<>(originalMap);

        for (class_3285 provider : this.aslib$additionalProviders) {
            provider.method_14453(profile -> extendedMap.put(profile.method_14463(), profile));
        }

        cir.setReturnValue(Collections.unmodifiableMap(extendedMap));
    }

    @Inject(method = "rebuildSelected", at = @At("RETURN"), cancellable = true)
    private void aslib$forceInjectRequiredPacks(Collection<String> collection, CallbackInfoReturnable<List<class_3288>> cir) {
        List<class_3288> originalSelected = cir.getReturnValue();

        List<class_3288> extendedSelected = new ArrayList<>(originalSelected);
        boolean modified = false;

        for (class_3285 provider : this.aslib$additionalProviders) {
            List<class_3288> customPacks = new ArrayList<>();
            provider.method_14453(customPacks::add);

            for (class_3288 pack : customPacks) {
                if (pack.method_14464() && !extendedSelected.contains(pack)) {
                    pack.method_14466().method_14468(extendedSelected, pack, com.google.common.base.Functions.identity(), false);
                    modified = true;
                }
            }
        }

        if (modified) {
            cir.setReturnValue(List.copyOf(extendedSelected));
        }
    }
}