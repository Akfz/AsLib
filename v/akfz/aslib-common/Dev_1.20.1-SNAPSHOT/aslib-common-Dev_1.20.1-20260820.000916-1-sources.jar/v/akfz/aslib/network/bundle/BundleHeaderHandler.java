package v.akfz.aslib.network.bundle;

import net.minecraft.class_3222;
import v.akfz.aslib.network.api.PacketHandler;

public final class BundleHeaderHandler implements PacketHandler<BundleHeaderPacket> {
    @Override
    public void handle(BundleHeaderPacket packet) {
        BundleManager.registerHeader(packet);
    }

    @Override
    public void handle(BundleHeaderPacket packet, class_3222 player) {
        BundleManager.registerHeader(packet);
    }
}