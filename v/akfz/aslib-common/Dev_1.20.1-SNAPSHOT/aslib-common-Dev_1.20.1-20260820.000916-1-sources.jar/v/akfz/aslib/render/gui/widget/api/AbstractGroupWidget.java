package v.akfz.aslib.render.gui.widget.api;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_364;
import net.minecraft.class_4069;

/**
 * For group (like scroll widgets or idk map widget, anything!)
 */
public abstract class AbstractGroupWidget extends AbstractWidget implements class_4069 {
    protected final List<AbstractWidget> children = new ArrayList<>();
    private class_364 focusedChild = null;
    private boolean isDragging = false;

    public AbstractGroupWidget(int x, int y, int width, int height) {
        super(x, y, width, height);
    }

    public void addWidget(AbstractWidget widget) {
        children.add(widget);
    }

    public void removeWidget(AbstractWidget widget) {
        if (focusedChild == widget) focusedChild = null;
        children.remove(widget);
    }

    public void clearWidgets() {
        children.clear();
        focusedChild = null;
    }

    @Override
    public List<? extends class_364> method_25396() {
        return children;
    }

    @Override
    public boolean method_25397() {
        return isDragging;
    }

    @Override
    public void method_25398(boolean dragging) {
        this.isDragging = dragging;
    }

    @Nullable
    @Override
    public class_364 method_25399() {
        return focusedChild;
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        this.focusedChild = focused;
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return visible && mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    public List<AbstractWidget> getChildren() {
        return children;
    }
}