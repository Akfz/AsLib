package v.akfz.aslib.datagen.api;

import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import net.minecraft.class_2960;

/**
 * @param <T> - output, like String or JsonElement and etc
 */
public interface Serializable<T> {
    @Nullable class_2960 getRLPath();
    @Nullable Path getPath();

    T serialize();

    /**
     * @return true - find path from getRLPath, false - find path from getPath
     */
    default boolean isAsset() {
        return true;
    }
    default String getExtension() {
        return "json";
    }

    /**
     * For generations like src/main...
     */
    default boolean isSystem() {
        return false;
    }
}
