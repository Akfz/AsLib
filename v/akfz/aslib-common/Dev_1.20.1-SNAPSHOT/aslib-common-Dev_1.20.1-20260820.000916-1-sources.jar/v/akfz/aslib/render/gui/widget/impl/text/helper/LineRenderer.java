package v.akfz.aslib.render.gui.widget.impl.text.helper;

import net.minecraft.class_332;

public interface LineRenderer {
    void render(class_332 graphics, String line, int x, int y, int lineIndex, int lineStartIndex, int defaultColor);
}