package v.akfz.aslib.world.preset;

import net.minecraft.class_2960;

/**
 * Preset enum representing standard vanilla dimension type identifiers.
 */
public enum VanillaDimensionTypes {
    OVERWORLD("overworld"),
    NETHER("the_nether"),
    END("the_end"),
    OVERWORLD_CAVES("overworld_caves");

    private final class_2960 location;

    VanillaDimensionTypes(String path) {
        this.location = new class_2960("minecraft", path);
    }

    public class_2960 location() {
        return location;
    }
}