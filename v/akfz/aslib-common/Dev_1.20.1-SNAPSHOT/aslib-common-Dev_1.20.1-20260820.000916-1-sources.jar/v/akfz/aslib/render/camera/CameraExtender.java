package v.akfz.aslib.render.camera;

import net.minecraft.class_243;

/**
 * For mixin.
 */
public interface CameraExtender {
    void addPos(class_243 pos);
    void addRot(class_243 rot);
    class_243 getRot();
    void clearRots();
    void clearPos();
    void setCustomRotsOnned(boolean customRotsOnned);
    float getRoll();
}
