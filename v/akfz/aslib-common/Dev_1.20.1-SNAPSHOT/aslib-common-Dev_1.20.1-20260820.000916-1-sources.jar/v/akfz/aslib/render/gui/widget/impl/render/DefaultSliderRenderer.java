package v.akfz.aslib.render.gui.widget.impl.render;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import v.akfz.aslib.render.color.ColorUtils;
import v.akfz.aslib.render.gui.widget.api.render.RenderExtras;
import v.akfz.aslib.render.gui.widget.api.render.RenderPart;

public class DefaultSliderRenderer implements RenderPart {

    @Override
    public void render(class_332 graphics, int mouseX, int mouseY, float delta, int x, int y, int width, int height, RenderExtras extras) {
        String label = extras.getOrDefault("label", String.class, "");
        double value = extras.getOrDefault("value", Double.class, 0.0);
        double progress = extras.getOrDefault("progress", Double.class, 0.0);
        boolean showValue = extras.getOrDefault("showValue", Boolean.class, true);
        boolean dragging = extras.getOrDefault("dragging", Boolean.class, false);
        boolean hovered = extras.getOrDefault("hovered", Boolean.class, false);
        boolean focused = extras.getOrDefault("focused", Boolean.class, false);

        int trackBgColor = ColorUtils.rgbToArgb(255, 25, 25, 25);
        int trackFillColor = ColorUtils.rgbToArgb(255, 70, 140, 240);
        int borderColor = focused ? 0xFFFFFFFF : ColorUtils.rgbToArgb(255, 100, 100, 100);

        int handleColor;
        if (dragging) {
            handleColor = ColorUtils.rgbToArgb(255, 180, 180, 180);
        } else if (hovered) {
            handleColor = ColorUtils.rgbToArgb(255, 140, 140, 140);
        } else {
            handleColor = ColorUtils.rgbToArgb(255, 90, 90, 90);
        }

        graphics.method_25294(x, y, x + width, y + height, trackBgColor);
        graphics.method_49601(x, y, width, height, borderColor);

        int handleWidth = 8;
        int trackScrollWidth = width - handleWidth - 4;
        int handleX = x + 4 + (int) (progress * trackScrollWidth);

        if (handleX > x + 4) {
            graphics.method_25294(x + 2, y + 2, handleX, y + height - 2, trackFillColor);
        }

        graphics.method_25294(handleX, y + 2, handleX + handleWidth, y + height - 2, handleColor);
        graphics.method_49601(handleX, y + 2, handleWidth, height - 4, ColorUtils.white());

        String displayStr = label;
        if (showValue) {
            String formattedValue = String.format("%.2f", value);
            displayStr = label.isEmpty() ? formattedValue : label + ": " + formattedValue;
        }

        if (!displayStr.isEmpty()) {
            class_327 font = class_310.method_1551().field_1772;
            class_2561 component = class_2561.method_43470(displayStr);

            int textX = x + (width - font.method_27525(component)) / 2;
            int textY = y + (height - font.field_2000) / 2;

            graphics.method_51439(font, component, textX, textY, ColorUtils.white(), true);
        }
    }
}